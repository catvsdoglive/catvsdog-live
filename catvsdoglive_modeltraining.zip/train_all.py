# train_all.py

import os
import random
from fastai.vision.all import *
from torchvision.models import resnet101, resnet50, resnet34, resnet18, resnet152
from torchvision.models import ResNet101_Weights, ResNet50_Weights, ResNet34_Weights, ResNet18_Weights, ResNet152_Weights
import torch
from fastai.callback.tracker import EarlyStoppingCallback, SaveModelCallback
import numpy as np
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from fastai.vision.core import PILImage
import warnings
import traceback
from pathlib import Path

# Suppress warnings
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", message=".*does not have many workers.*")

# Set random seed for reproducibility
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)  # If using multi-GPU
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_seed(42)  # Ensure consistent randomness across the entire script

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"⚙️  Using device: {device}")
if device.type == 'cuda':
    print(f"🖥️  CUDA device name: {torch.cuda.get_device_name(0)}")
else:
    print("🧠 Running on CPU")

# Function to Calculate Class Weights
def calculate_class_weights(class_weights_file, dls):
    """
    Reads class counts from a file and calculates class weights.

    Args:
        class_weights_file (str): Path to the class weights file.
        dls (DataLoaders): FastAI DataLoaders object.

    Returns:
        torch.Tensor: Tensor of class weights aligned with dls.vocab.
    """
    counts = {}
    with open(class_weights_file, 'r') as f:
        for line in f:
            parts = line.strip().split(':')
            if len(parts) != 2:
                print(f"Skipping invalid line in class_weights_file: {line}")
                continue
            class_name, count = parts
            try:
                counts[class_name] = int(count)
            except ValueError:
                print(f"Invalid count for class '{class_name}': {count}")
                counts[class_name] = 0  # Assign zero if count is invalid

    total = sum(counts.values())
    if total == 0:
        print("Total count of classes is zero. Assigning uniform weights.")
        weights = {cls: 1.0 for cls in dls.vocab}
    else:
        weights = {cls: total / count if count > 0 else 1.0 for cls, count in counts.items()}

    # Assign a default weight of 1.0 to classes with zero count to avoid inf
    for cls in dls.vocab:
        if cls not in weights:
            weights[cls] = 1.0

    # Ensure the weights are in the correct order matching dls.vocab
    weight_list = [weights.get(cls_name, 1.0) for cls_name in dls.vocab]

    return torch.tensor(weight_list).float().to(dls.device)

# Function to Save Confusion Matrix
def save_confusion_matrix(learn, dls, save_path='confusion_matrix.png'):
    """
    Computes and saves the confusion matrix as an image.

    Args:
        learn (Learner): Trained FastAI Learner object.
        dls (DataLoaders): FastAI DataLoaders object.
        save_path (str): Path to save the confusion matrix image.
    """
    preds, targets = learn.get_preds(dl=dls.valid)
    preds_labels = preds.argmax(dim=1)
    cm = confusion_matrix(targets, preds_labels)

    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', xticklabels=dls.vocab, yticklabels=dls.vocab, cmap='Blues')
    plt.xlabel('Predicted Label')
    plt.ylabel('Actual Label')
    plt.title('Confusion Matrix')
    plt.savefig(save_path)
    plt.close()

# Define Paths
root_dir = '<dataset main directory which must contain subdirs Cat, Dog and Other'  
save_dir = '<model saving directory>'  
class_weights_file = 'classweights.txt'

# Ensure save_dir exists
os.makedirs(save_dir, exist_ok=True)

# Verify Dataset Path and Structure
path = Path(root_dir)
if not path.exists():
    raise FileNotFoundError(f"Root directory does not exist: {root_dir}")

classes = [cls.name for cls in path.iterdir() if cls.is_dir()]
if not classes:
    raise ValueError(f"No class subdirectories found in: {root_dir}")
print(f"Classes found: {classes}")

# Check number of images per class
for cls in classes:
    num_images = len(list((path / cls).glob('*.*')))
    print(f"Class '{cls}' has {num_images} images.")
    if num_images == 0:
        print(f"Warning: Class '{cls}' has no images.")

# Validate the `class_weights_file`
if not os.path.isfile(class_weights_file):
    raise FileNotFoundError(f"Class weights file not found: {class_weights_file}")

# Define ImageNet Normalization Statistics
imagenet_stats = ([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])

# Import CrossEntropyLossFlat with label smoothing
from fastai.losses import CrossEntropyLossFlat

# Define the list of models with their specific attributes
models_info = [
    # {
        # "name": "resnet18",
        # "model_fn": resnet18,
        # "weights": ResNet18_Weights.DEFAULT,
        # "batch_size": 32
    # },
    # {
        # "name": "resnet34",
        # "model_fn": resnet34,
        # "weights": ResNet34_Weights.DEFAULT,
        # "batch_size": 32
    # },
    {
        "name": "resnet50",
        "model_fn": resnet50,
        "weights": ResNet50_Weights.DEFAULT,
        "batch_size": 32
    },
    {
        "name": "resnet101",
        "model_fn": resnet101,
        "weights": ResNet101_Weights.DEFAULT,
        "batch_size": 24
    },
    {
        "name": "resnet152",
        "model_fn": resnet152,
        "weights": ResNet152_Weights.DEFAULT,
        "batch_size": 16
    }
]

# Training Loop for Each Model
for model_info in models_info:
    model_name = model_info["name"]
    batch_size = model_info["batch_size"]
    print(f"\nStarting training for model: {model_name} with batch size: {batch_size}")
    
    try:
        # Create DataLoaders with model-specific batch size
        dls = ImageDataLoaders.from_folder(
            root_dir,
            valid_pct=0.20,
            item_tfms=[Resize(460)],  
            batch_tfms=[
                *aug_transforms(
                    size=224,
                    min_scale=0.8,      # Allow scaling down to 80% of the original size
                    flip_vert=False,     # Disable vertical flips
                    max_rotate=10,       # Rotate up to 10 degrees
                    max_zoom=1.1,        # Zoom in up to 10%
                    max_lighting=0.2,    # Adjust lighting up to 20%
                    max_warp=0.2,        # Warp up to 20%
                    p_affine=0.75,        # Apply affine transformations 75% of the time
                    p_lighting=0.75       # Apply lighting changes 75% of the time
                ),
                Normalize.from_stats(*imagenet_stats)
            ],
            bs=batch_size,  # Model-specific batch size
            num_workers=0  # Set num_workers as per your system's capacity
        )
        
        # Calculate Class Weights
        class_weights = calculate_class_weights(class_weights_file, dls)
        print(f"Class weights calculated for {model_name}")
        
        # Load the pretrained model
        pretrained_model = model_info["model_fn"](weights=model_info["weights"])

        # Create the body of the model with cut=-2
        body = create_body(pretrained_model, cut=-2)
        nf = num_features_model(body)

        # Create the custom head with 4 layers
        n_out = dls.c  # Number of output classes
        dropout_p = 0.3

        head = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.BatchNorm1d(nf),
            nn.Dropout(p=dropout_p),
            nn.Linear(nf, 512),
            nn.ReLU(),
            nn.BatchNorm1d(512),
            nn.Dropout(p=dropout_p),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.BatchNorm1d(256),
            nn.Dropout(p=dropout_p),
            nn.Linear(256, n_out)
        )

        # Combine body and head into a model
        model = nn.Sequential(body, head)

        # Create the Learner with label smoothing added to the loss function
        learn = Learner(
            dls,
            model,
            loss_func=CrossEntropyLossFlat(weight=class_weights, label_smoothing=0),
            metrics=[
                accuracy,
                Precision(average='macro'),
                Recall(average='macro'),
                F1Score(average='macro')
            ],
            wd=0.05,  # Weight decay
            path=save_dir
        )

        # Define the Callbacks
        callbacks = [
            SaveModelCallback(
                monitor='valid_loss',
                fname=f'best_{model_name}',
                comp=np.less,
                reset_on_fit=False
            ),
            EarlyStoppingCallback(
                monitor='valid_loss',
                patience=4
            )
        ]

        # Training Loop with 4 stages
        lr_max = 1e-4  # 0.0001

        # Stage 1: Train the classifier head
        learn.freeze()
        print(f"Stage 1: Training the head for {model_name} with lr_max={lr_max}")
        learn.fit_one_cycle(20, lr_max=lr_max, cbs=callbacks)

        # Stage 2: Unfreeze last two layers and train
        learn.freeze_to(-2)
        print(f"Stage 2: Fine-tuning last two layers for {model_name}")
        learn.fit_one_cycle(20, slice(lr_max/5, lr_max), cbs=callbacks)

        # Stage 3: Unfreeze last three layers and train
        learn.freeze_to(-3)
        print(f"Stage 3: Fine-tuning last three layers for {model_name}")
        learn.fit_one_cycle(20, slice(lr_max/100, lr_max/10), cbs=callbacks)

        # Stage 4: Unfreeze all layers and train
        learn.unfreeze()
        print(f"Stage 4: Fine-tuning all layers for {model_name}")
        learn.fit_one_cycle(20, slice(lr_max/1000, lr_max/10), cbs=callbacks)

        # Load the Best Model After Training
        try:
            learn.load(f'best_{model_name}')
            print(f"Loaded best model for {model_name}")
        except FileNotFoundError:
            print(f"Best model for {model_name} not found. Skipping load step.")

        # Validate the Best Model
        val_metrics = learn.validate()
        print(f'Best Model Validation Metrics for {model_name}:')
        print(f' - Loss: {val_metrics[0]:.4f}')
        print(f' - Accuracy: {val_metrics[1] * 100:.2f}%')
        print(f' - Precision: {val_metrics[2]:.4f}')
        print(f' - Recall: {val_metrics[3]:.4f}')
        print(f' - F1 Score: {val_metrics[4]:.4f}')

        # Save the Confusion Matrix
        confusion_matrix_path = os.path.join(save_dir, f'{model_name}_confusion_matrix.png')
        try:
            save_confusion_matrix(learn, dls, save_path=confusion_matrix_path)
            print(f"Confusion matrix saved at: {confusion_matrix_path}")
        except Exception as e:
            print(f"Failed to save confusion matrix for {model_name}: {e}")
            traceback.print_exc()

        # Export the Trained Model to the Specified Directory
        model_save_filename = f'{model_name}_model.pkl'
        try:
            learn.export(os.path.join(save_dir, model_save_filename))
            print(f"Model exported to: {os.path.join(save_dir, model_save_filename)}")
        except Exception as e:
            print(f"Failed to export model for {model_name}: {e}")
            traceback.print_exc()

    except RuntimeError as e:
        if 'out of memory' in str(e):
            print(f"Out of memory error with model {model_name}: {e}")
            print("Consider reducing the batch size or image size.")
        else:
            print(f"Runtime error with model {model_name}: {e}")
        traceback.print_exc()
    except Exception as e:
        print(f"An error occurred while training model {model_name}: {e}")
        traceback.print_exc()