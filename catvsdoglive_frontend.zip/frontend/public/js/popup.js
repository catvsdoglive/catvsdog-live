"use strict";

/*
 * popup.js
 * -----------------------------------------------------------
 *  Handles the "How It Works" popup overlay:
 *    - Creates an overlay and a popup modal.
 *    - Opens when the user clicks the #how-it-works link or automatically on first visit.
 *    - Closes ONLY when the user clicks the [I'm ready to count] button.
 *    - Disables page scrolling while active, re-enables on close.
 *    - The popup is automatically shown only once per session.
 * -----------------------------------------------------------
 */

$(document).ready(function () {
  // Acquire a reference to the #how-it-works element (trigger).
  const howItWorks = document.getElementById('how-it-works');
  if (!howItWorks) {
    console.error("Element with ID 'how-it-works' not found.");
    return; 
  }

  // Create the overlay and the popup container
  const overlay = document.createElement('div');
  overlay.className = 'overlay';

  const popup = document.createElement('div');
  popup.className = 'popup';
  popup.setAttribute('role', 'dialog');
  popup.setAttribute('aria-modal', 'true');
  popup.setAttribute('aria-labelledby', 'popup-title');
  popup.setAttribute('tabindex', '-1'); // Make popup focusable

  // Define the popup's inner HTML
  popup.innerHTML = `
    <h3 id="popup-title">How It Works</h3>
    <p>
      <span class="highlight-lightblue">Catvsdog.live</span> is a 
      <span class="highlight-warmbrown">real-time AI</span> that classifies tokens launched on
      <span class="highlight-softgreen">Pump.fun</span> as cats, dogs, or others.
      The number of cats and dogs is shown below.
    </p>
    <ul class="desktop-facts">
      <li><strong>Fact 1:</strong> Offers exceptional accuracy.</li>
      <li><strong>Fact 2:</strong> Utilizes deep convolutional neural networks (CNNs).</li>
      <li><strong>Fact 3:</strong> Pretrained on 60,000+ images.</li>
      <li><strong>Fact 4:</strong> Features... some features.</li>
      <li><strong>Fact 5:</strong> Developed with ChatGPT and Claude.</li>
    </ul>
    
    <!-- New link above the confirmation text -->
    <p style="margin-top: 1rem;">
      <a href="disclaimer.html" class="disclaimer-link">|Legal Disclaimer and Important Information|</a>
    </p>

    <!-- Confirmation text above the close button -->
    <p class="disclaimer-confirm" style="margin-bottom: 0.3rem;">
      <span class="highlight-paleyellow">by clicking this button below you confirm you have read the Legal Disclaimer and Important Information:</span>
    </p>
    <button id="close-popup" aria-label="Close popup" style="margin-top: 0;">[I'm ready to count]</button>
  `;

  // Append the overlay and popup to the body
  $('body').append(overlay, popup);

  // Helper function to calculate the width of the scrollbar
  function getScrollbarWidth() {
    const outer = document.createElement('div');
    outer.style.visibility = 'hidden';
    outer.style.overflow = 'scroll';
    outer.style.position = 'absolute';
    outer.style.top = '-9999px';
    document.body.appendChild(outer);

    const inner = document.createElement('div');
    outer.appendChild(inner);

    const scrollbarWidth = outer.offsetWidth - inner.offsetWidth;
    outer.remove();
    return scrollbarWidth;
  }

  // Store scrollbar width to adjust body padding when popup is shown
  const scrollbarWidth = getScrollbarWidth();

  // Show the popup, disable background scrolling, and move focus to the popup
  const openPopup = (event) => {
    if (event && event.preventDefault) {
      event.preventDefault();
    }
    overlay.classList.add('active');
    popup.classList.add('active');
    document.body.classList.add('no-scroll');

    // Adjust body padding for scrollbar offset
    if (scrollbarWidth > 0) {
      document.body.style.paddingRight = `${scrollbarWidth}px`;
    }
    popup.focus();
  };

  // Hide the popup, restore background scrolling, return focus to the trigger
  const closePopup = () => {
    overlay.classList.remove('active');
    popup.classList.remove('active');
    document.body.classList.remove('no-scroll');

    if (scrollbarWidth > 0) {
      document.body.style.paddingRight = '';
    }
    howItWorks.focus();
  };

  // Listen for click on #how-it-works to open
  howItWorks.addEventListener('click', openPopup);

  // Close ONLY when the user clicks the "[I'm ready to count]" button
  popup.querySelector('#close-popup').addEventListener('click', closePopup);

  // Automatically show popup on first page load in the session (if not already shown)
  if (!sessionStorage.getItem("popupDisplayed")) {
    setTimeout(function() {
      // Pass a dummy event with a preventDefault function
      openPopup({ preventDefault: function() {} });
      sessionStorage.setItem("popupDisplayed", "true");
    }, 100);
  }
});
