// sentiment-enhancements.js - Adds subtle visual improvements to the VADER sentiment gauge page

document.addEventListener('DOMContentLoaded', function() {
  // Apply color highlighting to sentiment values
  function updateSentimentColors() {
    // Update compound readout color
    const compoundReadout = document.getElementById('compound-readout');
    if (compoundReadout) {
      const text = compoundReadout.textContent;
      const match = text.match(/[-+]?[0-9]*\.?[0-9]+/);
      
      if (match) {
        const value = parseFloat(match[0]);
        
        if (value > 0.05) {
          compoundReadout.classList.add('positive-sentiment');
          compoundReadout.classList.remove('negative-sentiment', 'neutral-sentiment');
        } else if (value < -0.05) {
          compoundReadout.classList.add('negative-sentiment');
          compoundReadout.classList.remove('positive-sentiment', 'neutral-sentiment');
        } else {
          compoundReadout.classList.add('neutral-sentiment');
          compoundReadout.classList.remove('positive-sentiment', 'negative-sentiment');
        }
      }
    }
    
    // Update sentiment history colors
    const sentimentValues = [
      { id: 'sentiment-1hour', element: document.getElementById('sentiment-1hour') },
      { id: 'sentiment-4hours', element: document.getElementById('sentiment-4hours') },
      { id: 'sentiment-12hours', element: document.getElementById('sentiment-12hours') },
      { id: 'sentiment-24hr', element: document.getElementById('sentiment-24hr') },
      { id: 'sentiment-lifetime', element: document.getElementById('sentiment-lifetime') }
    ];
    
    sentimentValues.forEach(item => {
      if (item.element) {
        const text = item.element.textContent;
        const match = text.match(/[-+]?[0-9]*\.?[0-9]+/);
        
        if (match) {
          const value = parseFloat(match[0]);
          
          // Remove existing classes
          item.element.classList.remove('positive-sentiment', 'negative-sentiment', 'neutral-sentiment');
          
          // Add appropriate class based on value
          if (value > 0.05) {
            item.element.classList.add('positive-sentiment');
          } else if (value < -0.05) {
            item.element.classList.add('negative-sentiment');
          } else {
            item.element.classList.add('neutral-sentiment');
          }
        }
      }
    });
  }

  // Initially call updateSentimentColors
  updateSentimentColors();
  
  // Set up a MutationObserver to watch for changes in the sentiment values
  const observeConfig = { 
    childList: true, 
    characterData: true, 
    subtree: true 
  };
  
  const observer = new MutationObserver(function(mutations) {
    updateSentimentColors();
  });
  
  // Observe the compound readout
  const compoundReadout = document.getElementById('compound-readout');
  if (compoundReadout) {
    observer.observe(compoundReadout, observeConfig);
  }
  
  // Observe all sentiment history elements
  const historyElements = [
    document.getElementById('sentiment-1hour'),
    document.getElementById('sentiment-4hours'),
    document.getElementById('sentiment-12hours'),
    document.getElementById('sentiment-24hr'),
    document.getElementById('sentiment-lifetime')
  ];
  
  historyElements.forEach(element => {
    if (element) {
      observer.observe(element, observeConfig);
    }
  });
  
  // Add subtle pulsing effect to the needle when the value changes
  const originalUpdateGauge = window.updateGauge;
  if (typeof originalUpdateGauge === 'function') {
    window.updateGauge = function(compound) {
      originalUpdateGauge(compound);
      
      // Add subtle pulse effect
      const needle = document.getElementById('needle');
      if (needle) {
        needle.classList.add('pulse-animation');
        setTimeout(() => {
          needle.classList.remove('pulse-animation');
        }, 500);
      }
    };
  }
  
  // Enhance the rolling text container with alternating row styling
  function enhanceRollingText() {
    const container = document.getElementById('rollingTextContainer');
    if (container) {
      const items = container.children;
      for (let i = 0; i < items.length; i++) {
        // Skip already enhanced items
        if (items[i].getAttribute('data-enhanced') === 'true') {
          continue;
        }
        
        items[i].setAttribute('data-enhanced', 'true');
        
        // Add subtle hover effect
        items[i].style.transition = 'background-color 0.2s ease';
        items[i].style.borderRadius = '4px';
        items[i].style.padding = '1px 8px';
        
        // Add tooltips for truncated text
        if (items[i].scrollWidth > items[i].clientWidth) {
          items[i].title = items[i].textContent;
        }
      }
    }
  }
  
  // Set up a MutationObserver for the rolling text container
  const rollingTextContainer = document.getElementById('rollingTextContainer');
  if (rollingTextContainer) {
    const observer = new MutationObserver(function() {
      enhanceRollingText();
    });
    
    observer.observe(rollingTextContainer, { childList: true });
  }
  
  // Add hover effects to the sentiment periods
  const sentimentPeriods = document.querySelectorAll('.sentiment-period');
  sentimentPeriods.forEach(period => {
    period.addEventListener('mouseenter', function() {
      this.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
    });
    
    period.addEventListener('mouseleave', function() {
      this.style.backgroundColor = 'transparent';
    });
  });
  
  // Add subtle hover effect to top words container
  const topWordsContainer = document.getElementById('topWordsContainer');
  if (topWordsContainer) {
    topWordsContainer.addEventListener('mouseenter', function() {
      this.style.borderColor = 'rgba(134, 239, 172, 0.3)';
    });
    
    topWordsContainer.addEventListener('mouseleave', function() {
      this.style.borderColor = 'rgba(255, 255, 255, 0.1)';
    });
  }
});