document.addEventListener('DOMContentLoaded', () => {
  const btnOn = document.getElementById('toggleOn');
  const btnOff = document.getElementById('toggleOff');

  window.ttsEnabled = false; // Default "off"

  // Visual indicator for "off"
  btnOff.classList.add('active');

  btnOn.addEventListener('click', () => {
    if (!window.ttsEnabled) {
      // Switch from OFF to ON
      btnOn.classList.add('active');
      btnOff.classList.remove('active');
      window.ttsEnabled = true;
    }
    // Always play when ON button is clicked
    window.playTtsAudio();
  });

  btnOff.addEventListener('click', () => {
    if (window.ttsEnabled) {
      // Switch from ON to OFF
      btnOff.classList.add('active');
      btnOn.classList.remove('active');
      window.ttsEnabled = false;

      // Stop any currently playing audio
      if (window.currentAudio) {
        window.currentAudio.pause();
        window.currentAudio.currentTime = 0;
        window.currentAudio = null;
      }
    }
  });
});