"use strict";

/*
 * generator-ui.js
 * ----------------------------------------------------------
 *  - AI assist is OFF by default
 *  - Toggling AI assist ON => Generate Name pulses red,
 *    plus disable the category dropdown with an animation
 *  - If AI assist is ON => fetch from /get-generated-names
 *  - If AI assist is OFF => normal generateName(...) pipeline
 */

// AI assist flag
let isAiAssistEnabled = false;

// We'll store all generated names/tickers here:
let nameHistory = [];

/**
 * If AI assist is ON, fetch from /get-generated-names once,
 * store in local array, and pick from it on subsequent clicks.
 */
let cachedAiNames = [];

/**
 * highlightElon(str):
 *   If "elon" appears, highlight it in red.
 */
function highlightElon(str) {
  return str.replace(/elon/gi, (match) => `<span style="color:red">${match}</span>`);
}

/**
 * parseWordGenLine(lineFromPy):
 *   Example input: "Magic Moose [MOOSE]"
 *   We'll parse out the name vs. ticker:
 */
function parseWordGenLine(line) {
  const lastBracket = line.lastIndexOf("[");
  if (lastBracket < 0) {
    // fallback if format is unexpected
    return {
      finalName: line.trim(),
      finalTicker: "???"
    };
  }
  const namePart = line.slice(0, lastBracket).trim();
  const bracketPart = line.slice(lastBracket).trim(); // e.g. "[MOOSE]"
  const tickerMatch = bracketPart.match(/\[([^\]]+)\]/);
  let ticker = "???";
  if (tickerMatch && tickerMatch[1]) {
    ticker = tickerMatch[1].trim();
  }
  return {
    finalName: namePart,
    finalTicker: ticker
  };
}

/**
 * updateHistory():
 *   Renders nameHistory[] to #nameHistory in the DOM.
 */
function updateHistory() {
  const historyDiv = document.getElementById("nameHistory");
  if (!nameHistory.length) {
    historyDiv.innerHTML = "No history yet. Generate some names!";
    return;
  }

  // Build HTML
  historyDiv.innerHTML = nameHistory
    .map(item => {
      let style = item.color ? ` style="color:${item.color};"` : "";
      let text = `${item.name} [${item.ticker}]`;
      text = highlightElon(text);
      return `<div class="history-item"${style}>${text}</div>`;
    })
    .join("");
}

/**
 * showResultOnUI(name, ticker):
 *   Displays the final name/ticker on the page,
 *   updates nameHistory, etc.
 */
function showResultOnUI(name, ticker) {
  // Update the result area
  document.getElementById("tokenName").textContent = name;
  document.getElementById("ticker").textContent = `[${ticker}]`;

  // 50% chance to pick a random color for this entry
  const colorOptions = [
    "#82A9D1","#B4D7FE","#B8D5A8","#D2A48C","#D8A4C0","#E2E2AA",
    "#f5fe0e","#93c5fd","#86efac","#fca5a5"
  ];
  let chosenColor = null;
  if (Math.random() < 0.5) {
    chosenColor = colorOptions[Math.floor(Math.random() * colorOptions.length)];
  }

  // Store in nameHistory (front)
  nameHistory.unshift({ name, ticker, color: chosenColor });
  // Keep only last 100
  if (nameHistory.length > 100) {
    nameHistory.pop();
  }

  // Re-render
  updateHistory();
}

/**
 * copyToClipboard():
 *   Copies "name [TICKER]" from the UI to the clipboard.
 */
function copyToClipboard() {
  const nameEl = document.getElementById("tokenName");
  const tickerEl = document.getElementById("ticker");
  if (!nameEl || !tickerEl) return;

  const textToCopy = `${nameEl.textContent} ${tickerEl.textContent}`;
  navigator.clipboard
    .writeText(textToCopy)
    .then(() => {
      const copyButton = document.getElementById("copyButton");
      copyButton.textContent = "Copied!";
      copyButton.disabled = true;
      setTimeout(() => {
        copyButton.textContent = "Copy";
        copyButton.disabled = false;
      }, 2000);
    })
    .catch((err) => {
      console.error("Failed to copy text:", err);
      alert("Failed to copy text. Please try again.");
    });
}

/**
 * handleGenerateClick():
 *   If AI assist is ON => pick from our cached list of AI names (fetch if empty).
 *   Else => use the normal local generateName(...) pipeline.
 */
async function handleGenerateClick() {
  // 1) If AI assist is OFF => do normal local generation
  if (!isAiAssistEnabled) {
    const category = document.getElementById("categorySelect").value;
    // generateName comes from generator-logic.js
    const { name, ticker } = generateName(category);
    showResultOnUI(name, ticker);
    return;
  }

  // 2) If AI assist is ON => fetch from /get-generated-names (once)
  try {
    if (cachedAiNames.length === 0) {
      console.log("Fetching AI-generated names from the server...");
      const resp = await fetch("/get-generated-names");
      const data = await resp.json();
      if (!data.names || !data.names.length) {
        alert("No AI-generated names available. Please try again later.");
        return;
      }
      cachedAiNames = data.names;
      console.log(`Cached ${cachedAiNames.length} AI-generated names in memory.`);
    }

    // Pick a random line from cachedAiNames
    const randomLine = cachedAiNames[Math.floor(Math.random() * cachedAiNames.length)];
    const { finalName, finalTicker } = parseWordGenLine(randomLine);
    showResultOnUI(finalName, finalTicker);

  } catch (error) {
    console.error("Error fetching from /get-generated-names:", error);
    alert("Failed to retrieve AI token names. See console for details.");
  }
}

/**
 * initUI():
 *   Sets up event listeners, default states, etc.
 */
function initUI() {
  // Generate button
  const generateBtn = document.getElementById("generateButton");
  if (generateBtn) {
    generateBtn.addEventListener("click", handleGenerateClick);
  }

  // Copy button
  const copyBtn = document.getElementById("copyButton");
  if (copyBtn) {
    copyBtn.addEventListener("click", copyToClipboard);
  }

  // Category dropdown
  const catSelect = document.getElementById("categorySelect");

  // AI Assist button
  const aiAssistBtn = document.getElementById("aiAssistButton");
  if (aiAssistBtn && generateBtn && catSelect) {
    aiAssistBtn.classList.remove("active");
    generateBtn.classList.remove("pulsing-red");

    aiAssistBtn.addEventListener("click", () => {
      isAiAssistEnabled = !isAiAssistEnabled;
      aiAssistBtn.classList.toggle("active");

      if (isAiAssistEnabled) {
        // Turn ON => make "Generate" flash red
        generateBtn.classList.add("pulsing-red");

        // Disable dropdown
        catSelect.disabled = true;
        catSelect.classList.add("ai-disabled");
      } else {
        // Turn OFF => remove pulsing
        generateBtn.classList.remove("pulsing-red");

        // Re-enable dropdown
        catSelect.disabled = false;
        catSelect.classList.remove("ai-disabled");
      }
    });
  }
}

/**
 * On DOMContentLoaded => load data, init UI, plus open WS
 */
document.addEventListener("DOMContentLoaded", async () => {
  // 1) Load data (generator-logic.js)
  await initLogic();

  // If data is empty => disable "Generate Name"
  if (!Object.keys(data).length) {
    const btn = document.getElementById("generateButton");
    if (btn) {
      btn.disabled = true;
      alert("No data available. Please try again later.");
    }
  }

  // 2) Initialize UI (buttons, etc.)
  initUI();

  // 3) (New) Open a WebSocket to store cat/dog images in localStorage (no display needed)
  const ws = new WebSocket(location.protocol === 'https:' ? 
                         'wss://' + location.host + '/ws/' : 
                         'ws://' + location.host + '/ws/', 
                         'frontend-protocol');

  ws.onmessage = (evt) => {
    try {
      const data = JSON.parse(evt.data);
      if (data.type === 'cat-dog-images-update') {
        // Store them so the main page is also up-to-date later
        localStorage.setItem('latestCatImages', JSON.stringify(data.catImages || []));
        localStorage.setItem('latestDogImages', JSON.stringify(data.dogImages || []));
        localStorage.setItem('lastCatDogFetchTime', String(Date.now()));
      }
    } catch (err) {
      console.error('[generator-ui.js] WS parse error:', err);
    }
  };

  ws.onerror = (err) => {
    console.error('[generator-ui.js] WebSocket error:', err);
  };
});
