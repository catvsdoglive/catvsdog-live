// globalAudio.js

// Keep a reference to the currently playing Audio object, if any.
window.currentAudio = null;

/**
 * playTtsAudio():
 *   Loads "audio/trending-words-latest.wav" (cache-busted),
 *   stops any old playback, then starts the new audio.
 */
window.playTtsAudio = function() {
  // If there was a previous audio playing, stop it completely
  if (window.currentAudio) {
    window.currentAudio.pause();
    window.currentAudio.currentTime = 0;  // Reset to beginning
    window.currentAudio = null;
  }

  // Only create and play new audio if TTS is enabled
  if (window.ttsEnabled) {
    // Add a cache-busting parameter
    const audioUrl = `audio/trending-words-latest.wav?v=${Date.now()}`;
    const audio = new Audio(audioUrl);

    // Save it so we can stop it later if needed
    window.currentAudio = audio;

    // Attempt to play and properly handle cleanup if it fails
    audio.play().catch(err => {
      console.error('[globalAudio.js] Error playing TTS .wav:', err);
      if (window.currentAudio === audio) {
        window.currentAudio = null;  // Only clear if this is still the current audio
      }
    });

    // Add ended handler to clear reference
    audio.addEventListener('ended', () => {
      if (window.currentAudio === audio) {
        window.currentAudio = null;
      }
    });
  }
};