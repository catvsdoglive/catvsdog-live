// generator-enhancements.js - Adds interactivity to the token generator page

document.addEventListener('DOMContentLoaded', function() {
  // Step indicator functionality
  const categorySelect = document.getElementById('categorySelect');
  const generateButton = document.getElementById('generateButton');
  const aiAssistButton = document.getElementById('aiAssistButton');
  const copyButton = document.getElementById('copyButton');
  const steps = document.querySelectorAll('.step');
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');
  const copyToast = document.getElementById('copyToast');

  // Update step indicator based on user interactions
  function updateSteps(activeIndex) {
    steps.forEach((step, index) => {
      if (index === activeIndex) {
        step.classList.add('active');
      } else {
        step.classList.remove('active');
      }
    });
  }

  // Event listeners for step progression
  categorySelect.addEventListener('change', function() {
    updateSteps(0); // Step 1: Category Selection
  });

  generateButton.addEventListener('click', function() {
    updateSteps(1); // Step 2: Generate Name
    
    // Pulse animation for the result area
    const resultArea = document.querySelector('.result');
    resultArea.style.transition = 'all 0.2s ease';
    resultArea.style.boxShadow = '0 0 15px rgba(134, 239, 172, 0.8)';
    
    setTimeout(() => {
      resultArea.style.boxShadow = 'none';
    }, 500);
  });

  copyButton.addEventListener('click', function() {
    updateSteps(2); // Step 3: Copy & Use
    
    // Show the copy toast notification
    copyToast.classList.add('show');
    
    setTimeout(() => {
      copyToast.classList.remove('show');
    }, 2000);
  });

  // AI Assist button activation style
  aiAssistButton.addEventListener('click', function() {
    this.classList.toggle('active');
  });

  // Clear history functionality
  if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener('click', function() {
      const nameHistory = document.getElementById('nameHistory');
      if (nameHistory) {
        nameHistory.innerHTML = 'No history yet. Generate some names!';
        // Clear the history array if it exists in the original script
        if (window.nameHistory) {
          window.nameHistory = [];
        }
      }
    });
  }

  // Apply random spotlight effect on result hover
  const tokenNameDisplay = document.getElementById('tokenName');
  if (tokenNameDisplay) {
    tokenNameDisplay.addEventListener('mouseover', function() {
      if (this.textContent !== 'Click Generate to create a name!') {
        this.style.textShadow = `0 0 10px rgba(134, 239, 172, 0.8)`;
      }
    });
    
    tokenNameDisplay.addEventListener('mouseout', function() {
      this.style.textShadow = 'none';
    });
  }

  // Create typing animation effect for new tokens
  const originalShowResultOnUI = window.showResultOnUI;
  if (typeof originalShowResultOnUI === 'function') {
    window.showResultOnUI = function(name, ticker) {
      // Call the original function first
      originalShowResultOnUI(name, ticker);
      
      // Then apply the typing animation
      const nameElement = document.getElementById('tokenName');
      if (nameElement) {
        nameElement.style.opacity = '0';
        setTimeout(() => {
          nameElement.style.opacity = '1';
        }, 100); // Faster animation (100ms instead of 300ms)
      }
    };
  }

  // Enhance history items with hover effects
  function enhanceHistoryItems() {
    const historyItems = document.querySelectorAll('.history-item');
    historyItems.forEach(item => {
      if (!item.hasAttribute('data-enhanced')) {
        item.setAttribute('data-enhanced', 'true');
        
        // Apply padding consistently to all items
        item.style.padding = '4px 8px';
        item.style.borderRadius = '4px';
        item.style.transition = 'background-color 0.2s ease';
        item.style.cursor = 'pointer';
        
        item.addEventListener('mouseover', function() {
          this.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
        });
        
        item.addEventListener('mouseout', function() {
          this.style.backgroundColor = 'transparent';
        });
        
        item.addEventListener('click', function() {
          // Extract the name and ticker from the history item
          const content = this.textContent;
          const match = content.match(/(.*) \[(.*)\]/);
          
          if (match && match.length >= 3) {
            const name = match[1];
            const ticker = match[2];
            
            // Update the current result display
            const nameElement = document.getElementById('tokenName');
            const tickerElement = document.getElementById('ticker');
            
            if (nameElement && tickerElement) {
              nameElement.textContent = name;
              tickerElement.textContent = `[${ticker}]`;
              updateSteps(2);
            }
          }
        });
      }
    });
  }

  // Set up a mutation observer to watch for new history items
  const historyContainer = document.getElementById('nameHistory');
  if (historyContainer) {
    const observer = new MutationObserver(function() {
      enhanceHistoryItems();
    });
    
    observer.observe(historyContainer, { childList: true, subtree: true });
  }

  // Initialize by enhancing any existing history items
  enhanceHistoryItems();
});