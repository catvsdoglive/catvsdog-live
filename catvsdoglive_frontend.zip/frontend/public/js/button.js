document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('button');
  let isWindowOpen = false;
  let gameWindow = null;

  // Game State
  let turnNumber      = 1;
  let tokenPrice      = 0.00001; // initial price
  let totalSupply     = 0;       // total # of tokens => Market Cap
  let marketCap       = 10000;   // starts at $10k
  const GAME_OVER_THRESHOLD = 5000;  // if Market Cap <= 5k, game over

  let allEvents       = [];      // the raw array from game.json
  let selectedEvents  = [];      // shuffled events from allEvents
  let currentEventIndex = 0;     // which of the selectedEvents we’re on
  let chartInstance   = null;
  let currentEvent = null;

  /**
   * Shuffle the entire array so we get a random order for the events.
   * No slicing limit - we use all events.
   */
  function selectRandomEvents(allEvents) {
    return [...allEvents].sort(() => Math.random() - 0.5);
  }

  // Button toggles the game window
  button.addEventListener('click', () => {
    if (!isWindowOpen) {
      createGameWindow();
      isWindowOpen = true;
      button.textContent = 'game';
    } else {
      closeGameWindow();
      isWindowOpen = false;
      button.textContent = 'game';
    }
  });

  async function createGameWindow() {
    // 1) Create container
    const section = document.querySelector('.section');
    const sectionWidth = section ? section.offsetWidth : 600;

    gameWindow = document.createElement('div');
    gameWindow.style.cssText = `
      width: ${sectionWidth}px;
      margin: 16px auto;
      border-radius: 8px;
      transition: all 0.3s ease;
      opacity: 0;
      transform: translateY(-20px);
    `;

    // Insert below navbars
    const navbarsContainer = document.querySelector('.navbars-container');
    navbarsContainer.parentNode.insertBefore(gameWindow, navbarsContainer.nextSibling);

    // Keep width in sync if container resizes
    if (section) {
      new ResizeObserver(entries => {
        for (const entry of entries) {
          if (entry.target === section) {
            gameWindow.style.width = `${entry.target.offsetWidth}px`;
          }
        }
      }).observe(section);
    }

    // 2) Fetch & insert game window HTML
    try {
      const htmlResp = await fetch('game-window.html');
      const gameHtml = await htmlResp.text();
      gameWindow.innerHTML = gameHtml;
    } catch (err) {
      console.error('Failed to load game-window.html:', err);
      return;
    }

    // Animate game window open
    setTimeout(() => {
      gameWindow.style.opacity = '1';
      gameWindow.style.transform = 'translateY(0)';
    }, 0);

    // 3) Close button
    const closeBtn = gameWindow.querySelector('#closeGameBtn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        closeGameWindow();
        isWindowOpen = false;
        button.textContent = 'game';
      });
    }

    // 4) Load all events from JSON
    try {
      const resp = await fetch('game.json');
      allEvents = await resp.json();
    } catch (e) {
      console.error('Error loading game.json:', e);
      return;
    }

    // 5) Reset & start game
    // This also picks a new random event sequence
    resetGameState();
    initChart();
    showWelcomePopup();

    // 6) Reset Game button
    const resetGameBtn = gameWindow.querySelector('#resetGameBtn');
    if (resetGameBtn) {
      resetGameBtn.addEventListener('click', () => {
        closePopups();
        resetGameState();
        resetChartData();
        updateStatsDisplay();
        nextTurn();
      });
    }
  }

  function showWelcomePopup() {
    const welcomePopup = gameWindow.querySelector('#welcomePopup');
    if (!welcomePopup) return;

    welcomePopup.classList.add('show');

    // “OK” => hide popup, start first turn
    const okBtn = gameWindow.querySelector('#welcomeOkBtn');
    if (okBtn) {
      okBtn.onclick = () => {
        welcomePopup.classList.remove('show');
        nextTurn();
      };
    }
  }

  function closePopups() {
    const resultPopup = gameWindow.querySelector('#resultPopup');
    if (resultPopup) resultPopup.classList.remove('show');
    const gameOverPopup = gameWindow.querySelector('#gameOverPopup');
    if (gameOverPopup) gameOverPopup.classList.remove('show');
    const winnerPopup = gameWindow.querySelector('#winnerPopup');
    if (winnerPopup) winnerPopup.classList.remove('show');
  }

	function nextTurn() {
	  updateStatsDisplay();

	  if (currentEventIndex >= selectedEvents.length) {
		console.warn('No more events left!');
		return;
	  }

	  // Store the event globally so it can be shown later
	  currentEvent = selectedEvents[currentEventIndex++];

	  const turnEl    = gameWindow.querySelector('#turnNumber');
	  const iconEl    = gameWindow.querySelector('#eventIcon');
	  const nameEl    = gameWindow.querySelector('#eventName');
	  const descEl    = gameWindow.querySelector('#eventDescription');
	  const choicesEl = gameWindow.querySelector('#choices-area');

	  turnEl.textContent = turnNumber;
	  iconEl.textContent = currentEvent.icon || '🎲';
	  nameEl.textContent = currentEvent.name;
	  descEl.textContent = currentEvent.description;

	  choicesEl.innerHTML = '';
	  gameWindow.querySelector('.choices').classList.remove('disabled-choices');

	  currentEvent.choices.forEach(choice => {
		const btn = document.createElement('button');
		btn.classList.add('choice-button');
		btn.textContent = choice.text;
		btn.addEventListener('click', () => handleChoice(choice));
		choicesEl.appendChild(btn);
	  });
	}

  function handleChoice(choice) {
    // Disable additional clicks
    gameWindow.querySelector('.choices').classList.add('disabled-choices');

    // Random outcome by probability
    let rnd = Math.random(), cumulative = 0, chosenOutcome = null;
    for (const o of choice.outcomes) {
      cumulative += o.probability;
      if (rnd <= cumulative) {
        chosenOutcome = o;
        break;
      }
    }
    if (!chosenOutcome) {
      console.warn('No outcome matched probabilities; defaulting to zero effect.');
      chosenOutcome = { effect: 0, explanation: 'No outcome found.' };
    }

    const oldPrice = tokenPrice;
    // Apply compounding effect
    tokenPrice *= (1 + chosenOutcome.effect);
    marketCap = totalSupply * tokenPrice;

    // Check for Game Over
    if (marketCap <= GAME_OVER_THRESHOLD) {
      marketCap = GAME_OVER_THRESHOLD; // clamp
      updateChart(turnNumber, tokenPrice);
      // "true" => handle as game-over in result popup
      showResultPopup(chosenOutcome.effect, chosenOutcome.explanation, true, choice.text);
      return;
    }

    // Normal flow
    animatePriceChange(oldPrice, tokenPrice, chosenOutcome.effect, chosenOutcome.explanation, choice.text);
    turnNumber++;
    updateChart(turnNumber, tokenPrice);
  }

	function animatePriceChange(oldPrice, newPrice, effect, explanation, chosenText) {
	  const priceEl = gameWindow.querySelector('#priceDisplay');
	  if (!priceEl) return;

	  // Existing color-coded style
	  if (newPrice > oldPrice) {
		priceEl.classList.remove('price-down');
		priceEl.classList.add('price-up');
	  } else {
		priceEl.classList.remove('price-up');
		priceEl.classList.add('price-down');
	  }

	  // Show normal outcome popup
	  showResultPopup(effect, explanation, false, chosenText);
	}

function showResultPopup(effect, explanation, thenGameOver, choiceText = '') {
  const popup  = gameWindow.querySelector('#resultPopup');
  const amtEl  = gameWindow.querySelector('#resultAmount');
  const explEl = gameWindow.querySelector('#resultExplanation');
  const okBtn  = gameWindow.querySelector('#popupOk');
  if (!popup || !amtEl || !explEl || !okBtn) return;

  // Format and color-code the effect
  const pct = (effect * 100).toFixed(1) + '%';
  if (effect >= 0) {
    amtEl.textContent = '+' + pct;
    amtEl.classList.remove('negative');
    amtEl.classList.add('positive');
  } else {
    amtEl.textContent = pct;
    amtEl.classList.remove('positive');
    amtEl.classList.add('negative');
  }
  explEl.textContent = explanation || '(No explanation provided)';
  popup.classList.add('show');

  okBtn.onclick = () => {
    popup.classList.remove('show');

    // Update “Last Result” to include the chosen choice text
    const lastResultEl = gameWindow.querySelector('#lastResult');
    if (lastResultEl) {
      lastResultEl.textContent =
        `Last result (Choice: ${choiceText}) => ` +
        `${amtEl.textContent} — ${explEl.textContent}`;
    }

    // Also update “Last Event” as before
    const lastEventEl = gameWindow.querySelector('#lastEvent');
    if (lastEventEl && currentEvent) {
      lastEventEl.textContent = `Last event: ${currentEvent.name} — ${currentEvent.description}`;
    }

    // Continue normal flow
    const priceEl = gameWindow.querySelector('#priceDisplay');
    if (priceEl) {
      priceEl.classList.remove('price-up', 'price-down');
    }
    updateStatsDisplay();

    if (thenGameOver) {
      showGameOverPopup();
    } else {
      if (turnNumber >= 100 || marketCap >= 1000000000) {
        showWinPopup();
      } else {
        nextTurn();
      }
    }
  };
}

  function showWinPopup() {
    closePopups();
    const winnerPopup = gameWindow.querySelector('#winnerPopup');
    if (!winnerPopup) {
      alert("Congratulations! You beat the odds (no winnerPopup element).");
      return;
    }

    const finalTurnEl = gameWindow.querySelector('#finalTurn');
    const finalMarketCapEl = gameWindow.querySelector('#finalMarketCap');

    if (finalTurnEl) finalTurnEl.textContent = turnNumber;
    if (finalMarketCapEl) finalMarketCapEl.textContent = formatMarketCap(marketCap);

    winnerPopup.classList.add('show');
    const winnerOkBtn = gameWindow.querySelector('#winnerOkBtn');
    if (winnerOkBtn) {
      winnerOkBtn.onclick = () => {
        winnerPopup.classList.remove('show');
        resetGameState();
        resetChartData();
        updateStatsDisplay();
        nextTurn();
      };
    }
  }

  function showGameOverPopup() {
    closePopups();
    const gameOverPopup = gameWindow.querySelector('#gameOverPopup');
    if (!gameOverPopup) return;

    gameOverPopup.classList.add('show');
    const retryBtn = gameWindow.querySelector('#retryBtn');
    retryBtn.onclick = () => {
      gameOverPopup.classList.remove('show');
      resetGameState();
      resetChartData();
      updateStatsDisplay();
      nextTurn();
    };
  }

  function updateStatsDisplay() {
    if (!gameWindow) return;
    const turnEl      = gameWindow.querySelector('#turnNumber');
    const priceEl     = gameWindow.querySelector('#priceDisplay');
    const marketCapEl = gameWindow.querySelector('#walletDisplay');

    if (turnEl)      turnEl.textContent      = turnNumber;
    if (priceEl)     priceEl.textContent     = tokenPrice.toFixed(8);
    // UPDATED: Market cap with commas
    if (marketCapEl) marketCapEl.textContent = formatMarketCap(marketCap);
  }

  // Helper to format large numbers with commas, always 2 decimals
  function formatMarketCap(value) {
    return '$' + value.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }

  function initChart() {
    const canvas = gameWindow.querySelector('#chartCanvas');
    if (!canvas || !window.Chart) return;

    const ctx = canvas.getContext('2d');
    chartInstance = new Chart(ctx, {
      type: 'line',
      data: {
        labels: [ 'Turn 1' ],
        datasets: [{
          label: 'Token Price',
          data: [ tokenPrice ],
          borderColor: '#61e786',
          backgroundColor: 'rgba(97,231,134,0.2)',
          fill: true,
          tension: 0.2
        }]
      },
      options: {
        scales: {
          x: { display: false },
          y: {
            display: true,
            beginAtZero: false,
            title: { display: true, text: 'Price (USD)' },
            ticks: {
              callback: val => Number(val).toExponential(2)
            }
          }
        },
        plugins: { legend: { display: false } },
        responsive: true,
        maintainAspectRatio: false
      }
    });
  }

  function updateChart(turn, price) {
    if (!chartInstance) return;
    chartInstance.data.labels.push(`Turn ${turn}`);
    chartInstance.data.datasets[0].data.push(price);
    chartInstance.update();
  }

  /**
   * Reset the game’s base variables and pick a new random event sequence.
   */
	function resetGameState() {
	  turnNumber  = 1;
	  tokenPrice  = 0.00001;
	  totalSupply = 10000 / tokenPrice;
	  marketCap   = 10000;

	  // Shuffle entire event list
	  selectedEvents = selectRandomEvents(allEvents);
	  currentEventIndex = 0;

	  // Clear “Last Result” and “Last Event”
	  if (gameWindow) {
		const lastResultEl = gameWindow.querySelector('#lastResult');
		if (lastResultEl) {
		  lastResultEl.textContent = '';
		}
		const lastEventEl = gameWindow.querySelector('#lastEvent');
		if (lastEventEl) {
		  lastEventEl.textContent = '';
		}
	  }
	}
  
  function resetChartData() {
    if (!chartInstance) return;
    chartInstance.data.labels = [ 'Turn 1' ];
    chartInstance.data.datasets[0].data = [ tokenPrice ];
    chartInstance.update();
  }

  function closeGameWindow() {
    if (!gameWindow) return;
    if (chartInstance) {
      chartInstance.destroy();
      chartInstance = null;
    }
    gameWindow.style.opacity = '0';
    gameWindow.style.transform = 'translateY(-20px)';
    setTimeout(() => {
      if (gameWindow) {
        gameWindow.remove();
      }
      gameWindow = null;
    }, 300);
  }
});

