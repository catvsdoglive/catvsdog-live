"use strict"; // Enable strict mode

/*
 * counter.js
 * -------------------------------------------------------------
 *  Handles real-time cat/dog counters, trending words, and 
 *  the "current processing" image in the UI. It fetches data 
 *  via REST and also listens for WebSocket updates to ensure 
 *  a reactive front-end for cat vs. dog tracking.
 *
 *  MAIN FUNCTIONS:
 *    - initializeCounters(), initializeTrendingWords():
 *        Fetch counters/trending words via REST.
 *    - initializeCatDogImages(), initializeCurrentProcessedImage():
 *        Fetch array-based cat/dog images and the "current processing" image.
 *    - initializeWebSocket():
 *        Opens a WebSocket to receive real-time updates (e.g., counters-update).
 *    - handleWebSocketMessage():
 *        Processes data from the server, updating the UI accordingly.
 *    - attemptReconnect():
 *        Implements exponential backoff if the WebSocket disconnects.
 * 
 *  NOTE: 
 *    - #trend-box-1..9, #container1, #container2, #current-processing-image, etc.
 *      are elements in the HTML that get updated dynamically.
 *    - The code avoids handling certain messages like 'vader-sentiment'
 *      or 'sentiment-history' to reduce warnings in the console.
 * -------------------------------------------------------------
 */

/**
 * CONFIGURATION & GLOBAL STATE
 */
const maxReconnectAttempts = 10;
let reconnectAttempts = 0;
let receivedFullState = false;  // Tracks if the full state was received at least once

/** Dynamic values using relative URLs and protocol detection */
const API_BASE_URL = ''; // Empty string for relative URLs
const TRENDING_WORDS_API = '/get-trending-words';
const COUNTERS_API = '/get-counters';
const CAT_DOG_IMAGES_API = '/get-cat-dog-images';
const CURRENT_PROCESSING_API = '/get-current-processing-image';
const WS_URL = location.protocol === 'https:' ? 
               'wss://' + location.host + '/ws/' : 
               'ws://' + location.host + '/ws/';

/** jQuery references for DOM elements */
const websocketStatusEl = $('#websocket-status');
const totalImagesEl = $('#total-images');
const currentProcessingImageEl = $('#current-processing-image');
const currentProcessingContainerEl = $('#current-processing-container');
const classificationEl = $('#current-classification');
const confidenceEl = $('#confidence-score');
const tokenTickerEl = $('#token-ticker');
const tokenAddressEl = $('#token-address');

/** Throttle intervals, etc. */
const CAT_DOG_FETCH_INTERVAL_MS = 300000;   // 5 minutes
const MIN_GRID_UPDATE_INTERVAL = 500;      // 0.5 seconds (avoid flicker on frequent backend updates)

/** Counters stored locally and updated from REST or WS. */
let counters = {
  catCount: 0,
  dogCount: 0,
  otherCount: 0
};

/** 
 * Memory state for arrays of cat/dog images (multi-image) 
 * plus the current processing image. 
 */
const memoryState = {
  currentProcessing: {
	tokenAddress: 'N/A',  
    imageUrl: '',
    classification: 'N/A',
    confidence: 'N/A',
    tokenTicker: 'N/A'
  },
  latestCatImages: [],
  latestDogImages: []
};

/** Display counts controlled by dropdowns (1, 4, or 9) */
let catDisplayCount = 1;
let dogDisplayCount = 1;

// Mobile tap‑to‑cycle sizes & state
const SIZES    = [1, 4, 9];
const catState = { index: SIZES.indexOf(catDisplayCount) };
const dogState = { index: SIZES.indexOf(dogDisplayCount) };

/** Snapshots to skip re-render if arrays didn't change */
let lastCatImagesSnapshot = [];
let lastDogImagesSnapshot = [];

/** Timestamp for skipping repeated updates within a short period */
let lastCatDogFetchTime = 0;
let lastGridUpdateTime = 0;

// ----------------------------------------------------------------------------
// FLASH‐AND‐GRID COORDINATION
// ----------------------------------------------------------------------------
// When true, we're mid-flash on the "current processing" image.
let imageInFlight = false;
// If a grid update arrives while imageInFlight, defer it here.
let pendingGridUpdate = false;

/**
 * Triggers the yellow flash every time (removes-reflows-readds the class),
 * and calls onEnd() when the CSS animation really finishes.
 *
 * @param {jQuery|Element} overlayEl – the .flash-overlay container
 * @param {Function}       onEnd       – callback after animation ends
 */
function triggerYellowFlash(overlayEl, onEnd) {
  const $ol = overlayEl instanceof jQuery ? overlayEl : $(overlayEl);
  const dom = $ol[0];

  // 1) strip the class so re-adding actually restarts the keyframes
  $ol.removeClass('flash-yellow');
  // 2) force a reflow
  void dom.offsetWidth;
  // 3) listen once for the real end of the CSS animation
  $ol
    .off('animationend.flashYellow')
    .on ('animationend.flashYellow', () => {
      $ol.removeClass('flash-yellow');
      if (typeof onEnd === 'function') onEnd();
    })
    // 4) kick off the animation
    .addClass('flash-yellow');
}

/* ------------------------------------------------------------------
   PART 1: INITIAL REST FETCHES
   ------------------------------------------------------------------ */

/**
 * Grabs cat/dog/other counters via REST and updates the UI.
 */
function initializeCounters() {
  $.getJSON(COUNTERS_API)
    .done((data) => {
      counters.catCount = data.catCount || 0;
      counters.dogCount = data.dogCount || 0;
      counters.otherCount = data.otherCount || 0;
      updateCounter(counters.catCount, 'counter1');
      updateCounter(counters.dogCount, 'counter2');
      updateTotalImages();
    })
    .fail((_, textStatus, error) => {
      console.error('Error fetching counters:', textStatus, error);
    });
}

/**
 * Truncates text to fit inside an element, adding '...' if necessary.
 * Also sets the full text as a title attribute for hover tooltip.
 * @param {string} text - The original text to display
 * @param {jQuery} $element - The jQuery element to fit text into
 */
function truncateTextToFit(text, $element) {
  // Always set the full text as a title for hover
  $element.attr('title', text);
  
  // If text is short (less than 10 chars), just display it
  if (text.length < 10) {
    $element.text(text);
    return;
  }
  
  // Get the element width
  const boxWidth = $element.width();
  
  // Create a temporary span to measure text width
  const $measureSpan = $('<span>')
    .css({
      'font-family': $element.css('font-family'),
      'font-size': $element.css('font-size'),
      'font-weight': $element.css('font-weight'),
      'visibility': 'hidden',
      'position': 'absolute',
      'white-space': 'nowrap'
    })
    .text(text)
    .appendTo('body');
  
  // Measure the text width
  const textWidth = $measureSpan.width();
  
  // Remove the measuring span
  $measureSpan.remove();
  
  // If text fits, use it as is
  if (textWidth <= boxWidth) {
    $element.text(text);
    return;
  }
  
  // Text doesn't fit, truncate with ellipsis
  let truncated = text;
  const ellipsis = '...';
  
  // Binary search for the right length
  let start = 0;
  let end = text.length - 1;
  
  while (start <= end) {
    const mid = Math.floor((start + end) / 2);
    const testText = text.substring(0, mid) + ellipsis;
    
    $measureSpan.text(testText).appendTo('body');
    const testWidth = $measureSpan.width();
    $measureSpan.remove();
    
    if (testWidth <= boxWidth) {
      truncated = testText;
      start = mid + 1;
    } else {
      end = mid - 1;
    }
  }
  
  // Set the truncated text
  $element.text(truncated);
}

/**
 * Safely parse an array from localStorage, returning [] if invalid/missing.
 */
function safeParseImages(key) {
  const raw = localStorage.getItem(key);
  if (!raw || raw === 'undefined' || raw === 'null') {
    return [];
  }
  try {
    return JSON.parse(raw);
  } catch (error) {
    console.error(`Error parsing ${key} from localStorage:`, error);
    return [];
  }
}

/**
 * Loads cat/dog images from localStorage, displays them,
 * then optionally fetches fresh data if older than CAT_DOG_FETCH_INTERVAL_MS.
 */
function initializeCatDogImages() {
  // 1) Load from localStorage if available
  const catImages = safeParseImages('latestCatImages');
  const dogImages = safeParseImages('latestDogImages');

  // 2) Display cached images if they exist
  if (catImages.length && dogImages.length) {
    memoryState.latestCatImages = catImages;
    memoryState.latestDogImages = dogImages;
    updateMultipleImagesDisplayThrottled(); // avoid flicker on repeated updates
  }

  // 3) If stale, fetch fresh data from the server
  const lastFetch = parseInt(localStorage.getItem('lastCatDogFetchTime'), 10) || 0;
  if (Date.now() - lastFetch >= CAT_DOG_FETCH_INTERVAL_MS) {
    $.getJSON(CAT_DOG_IMAGES_API)
      .done((data) => {
        localStorage.setItem('latestCatImages', JSON.stringify(data.catImages || []));
        localStorage.setItem('latestDogImages', JSON.stringify(data.dogImages || []));
        localStorage.setItem('lastCatDogFetchTime', String(Date.now()));

        memoryState.latestCatImages = data.catImages || [];
        memoryState.latestDogImages = data.dogImages || [];
        updateMultipleImagesDisplayThrottled();
      });
  }
}

/**
 * Retrieves trending words (an array of 9 words) from the server.
 */
function initializeTrendingWords() {
	$.getJSON(TRENDING_WORDS_API)
	  .done((data) => {
		if (data.words && Array.isArray(data.words) && data.words.length >= 9) {
		  for (let i = 1; i <= 9; i++) {
			const $trendBox = $(`#trend-box-${i}`);
			truncateTextToFit(data.words[i - 1] || 'N/A', $trendBox);
		  }
		}
	  })
	  .fail((_, textStatus, error) => {
		console.error('Error fetching trending words:', textStatus, error);
	  });
}

/**
 * Fetches the latest "current processing" image via REST and updates the UI.
 */
function initializeCurrentProcessedImage() {
  $.getJSON(CURRENT_PROCESSING_API)
    .done((data) => {
	  memoryState.currentProcessing.tokenAddress = data.tokenAddress || 'N/A';
      memoryState.currentProcessing.imageUrl = data.imageUrl || '';
      memoryState.currentProcessing.classification = data.classification || 'N/A';
      memoryState.currentProcessing.confidence = data.confidence || 'N/A';
      memoryState.currentProcessing.tokenTicker = data.tokenTicker || 'N/A';
      updateProcessingImageDisplay();
    })
    .fail((_, textStatus, error) => {
      console.error('Error fetching current processing image:', textStatus, error);
    });
}

/* ------------------------------------------------------------------
   PART 2: UI UPDATE FUNCTIONS
   ------------------------------------------------------------------ */

/**
 * Throttled function to avoid flicker on repeated backend updates.
 * If user explicitly changes grid size, we'll skip this approach
 * and do an immediate update.
 */
function updateMultipleImagesDisplayThrottled() {
  const now = Date.now();
  if (now - lastGridUpdateTime < MIN_GRID_UPDATE_INTERVAL) {
    // Not enough time has passed => skip this update
    return;
  }
  lastGridUpdateTime = now;
  updateMultipleImagesDisplay();
}

/**
 * For user-initiated grid size changes (instantly apply),
 * ignoring throttles & array-checks. This ensures immediate layout change.
 */
function updateGridLayoutImmediate() {
  // 1) Clear + re-render grid layout
  const catGrid = $('#container1');
  const dogGrid = $('#container2');
  setupGridLayout(catGrid, catDisplayCount);
  setupGridLayout(dogGrid, dogDisplayCount);

  // 2) Append the same images from memoryState
  const catSubset = memoryState.latestCatImages.slice(0, catDisplayCount);
  const dogSubset = memoryState.latestDogImages.slice(0, dogDisplayCount);

  catSubset.forEach((catUrl) => {
    const imgContainer = $('<div class="relative w-full h-full">');
    imgContainer.append('<div class="absolute inset-0 bg-gray-200 animate-pulse rounded-md"></div>');

    const img = $(`<img
      src="${catUrl}"
      alt="cat"
      class="object-cover w-full h-full rounded-md"
    />`);
    img.on('load', function() {
      $(this).prev('.animate-pulse').remove();
    });
    imgContainer.append(img);
    catGrid.append(imgContainer);
  });

  dogSubset.forEach((dogUrl) => {
    const imgContainer = $('<div class="relative w-full h-full">');
    imgContainer.append('<div class="absolute inset-0 bg-gray-200 animate-pulse rounded-md"></div>');

    const img = $(`<img
      src="${dogUrl}"
      alt="dog"
      class="object-cover w-full h-full rounded-md"
    />`);
    img.on('load', function() {
      $(this).prev('.animate-pulse').remove();
    });
    imgContainer.append(img);
    dogGrid.append(imgContainer);
  });
}

/**
 * Checks whether two arrays are identical (strict equality of items).
 */
function arraysAreEqual(arr1, arr2) {
  if (arr1.length !== arr2.length) return false;
  for (let i = 0; i < arr1.length; i++) {
    if (arr1[i] !== arr2[i]) return false;
  }
  return true;
}

/**
 * The standard function to re-render cat/dog images,
 * skipping if arrays haven't changed.
 */
function updateMultipleImagesDisplay() {
  const catGrid = $('#container1');
  const dogGrid = $('#container2');
  
  // Setup grid layouts
  setupGridLayout(catGrid, catDisplayCount);
  setupGridLayout(dogGrid, dogDisplayCount);

  // Get image subsets
  const catSubset = memoryState.latestCatImages.slice(0, catDisplayCount);
  const dogSubset = memoryState.latestDogImages.slice(0, dogDisplayCount);

  // Add cat images
  catSubset.forEach((catUrl) => {
    const imgContainer = $('<div class="relative aspect-square w-full">');
    imgContainer.append('<div class="absolute inset-0 bg-gray-200 animate-pulse rounded-md"></div>');

    const img = $(`<img
      src="${catUrl}"
      alt="cat"
      class="absolute inset-0 object-cover w-full h-full rounded-md"
    />`);
    img.on('load', function() {
      $(this).prev('.animate-pulse').remove();
    });
    imgContainer.append(img);
    catGrid.append(imgContainer);
  });

  // Add dog images
  dogSubset.forEach((dogUrl) => {
    const imgContainer = $('<div class="relative aspect-square w-full">');
    imgContainer.append('<div class="absolute inset-0 bg-gray-200 animate-pulse rounded-md"></div>');

    const img = $(`<img
      src="${dogUrl}"
      alt="dog"
      class="absolute inset-0 object-cover w-full h-full rounded-md"
    />`);
    img.on('load', function() {
      $(this).prev('.animate-pulse').remove();
    });
    imgContainer.append(img);
    dogGrid.append(imgContainer);
  });
}

/**
 * Sets up the grid layout (# of columns) based on displayCount.
 */
function setupGridLayout(grid, displayCount) {
  // Clear existing content
  grid.empty();
  
  // Always maintain aspect-square
  grid.addClass('aspect-square w-full');

  if (displayCount === 1) {
    grid
      .removeClass('grid grid-cols-2 grid-cols-3 gap-2')
      .addClass('relative');
  } else if (displayCount === 4) {
    grid
      .removeClass('relative grid-cols-3')
      .addClass('grid grid-cols-2 gap-2');
  } else if (displayCount === 9) {
    grid
      .removeClass('relative grid-cols-2')
      .addClass('grid grid-cols-3 gap-2');
  }
}

/**
 * Displays the "current processing" image and text (classification, confidence).
 */
function updateProcessingImageDisplay() {
  if (currentProcessingImageEl.length) {
    currentProcessingImageEl.attr('src', memoryState.currentProcessing.imageUrl || '');
  }
  if (classificationEl.length) {
    classificationEl.text(memoryState.currentProcessing.classification);
  }
  if (confidenceEl.length) {
    confidenceEl.text(memoryState.currentProcessing.confidence);
  }
  if (tokenTickerEl.length) {
    tokenTickerEl.text(memoryState.currentProcessing.tokenTicker);
  }
  if (tokenAddressEl.length) {
    tokenAddressEl.text(memoryState.currentProcessing.tokenAddress);
  }
}

/**
 * Displays a 7-digit padded counter, with a brief highlight animation.
 */
function updateCounter(counterValue, idPrefix) {
  const digits = counterValue.toString().padStart(7, '0');
  for (let i = 0; i < digits.length; i++) {
    const digitElement = $(`#${idPrefix}-digit${i + 1}`);
    if (digitElement.length) {
      digitElement.text(digits[i]);
      // Brief highlight animation
      digitElement.addClass('updated-digit');
      setTimeout(() => digitElement.removeClass('updated-digit'), 500);
    }
  }
}

/**
 * Reflects total processed = cat + dog + other
 */
function updateTotalImages() {
  const totalImagesProcessed = counters.catCount + counters.dogCount + counters.otherCount;
  if (totalImagesEl.length) {
    totalImagesEl.text(totalImagesProcessed);
  }
}

/* ------------------------------------------------------------------
   PART 3: WEBSOCKET LOGIC
   ------------------------------------------------------------------ */

function initializeWebSocket() {
  const socket = new WebSocket(WS_URL);

  socket.onopen = () => {
    reconnectAttempts = 0;
    if (websocketStatusEl.length) {
      websocketStatusEl
        .text('Connected')
        .removeClass('text-red-500')
        .addClass('text-green-500');
    }
    // Optionally request the full state immediately
    socket.send(JSON.stringify({ type: 'request-full-state' }));
  };

  socket.onmessage = (event) => {
    try {
      if (!event.data) return;
      const data = JSON.parse(event.data);
      handleWebSocketMessage(data);
    } catch (error) {
      console.error('Error parsing WebSocket message:', error);
    }
  };

  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
    if (websocketStatusEl.length) {
      websocketStatusEl
        .text('Error')
        .removeClass('text-green-500')
        .addClass('text-red-500');
    }
  };

  socket.onclose = (event) => {
    console.warn(`WebSocket closed: Code=${event.code}, Reason=${event.reason}`);
    if (websocketStatusEl.length) {
      websocketStatusEl
        .text('Reconnecting...')
        .removeClass('text-green-500')
        .addClass('text-yellow-500');
    }
    attemptReconnect();
  };
}

/**
 * Reconnects on close, with exponential backoff.
 */
function attemptReconnect() {
  if (reconnectAttempts < maxReconnectAttempts) {
    const reconnectDelay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000);
    setTimeout(() => {
      reconnectAttempts++;
      initializeWebSocket();
    }, reconnectDelay);
  } else {
    console.error('Max reconnection attempts reached.');
    if (websocketStatusEl.length) {
      websocketStatusEl
        .text('Disconnected')
        .removeClass('text-yellow-500')
        .addClass('text-red-500');
    }
  }
}

/**
 * Handles incoming WebSocket messages (JSON).
 */
function handleWebSocketMessage(data) {
  switch (data.type) {
    case 'full-state':
      // We just connected or reconnected—refresh everything from REST
      receivedFullState = true;
      initializeCatDogImages();
      initializeCounters();
      initializeTrendingWords();
      initializeCurrentProcessedImage();
      break;

	case 'trending-words-update':
	  if (Array.isArray(data.words)) {
		for (let i = 1; i <= 9; i++) {
		  const $trendBox = $(`#trend-box-${i}`);
		  truncateTextToFit(data.words[i - 1] || 'N/A', $trendBox);
		}
		// Optional TTS
		if (window.ttsEnabled) {
		  playTtsAudio();
		}
	  }
	  break;

		case 'image-prediction':
		  // "Current processing" image info + counters
		  if (typeof data.catCount === 'number') {
			counters.catCount = data.catCount;
			updateCounter(counters.catCount, 'counter1');
		  }
		  if (typeof data.dogCount === 'number') {
			counters.dogCount = data.dogCount;
			updateCounter(counters.dogCount, 'counter2');
		  }
		  if (typeof data.otherCount === 'number') {
			counters.otherCount = data.otherCount;
		  }
		  updateTotalImages();
		  
		  // classification + imageUrl => update "current processing" display
		  if (data.classification && data.imageUrl) {
			const bustUrl = `${data.imageUrl}?v=${Date.now()}`;
			memoryState.currentProcessing = {
			  tokenAddress: data.tokenAddress || 'N/A',
			  imageUrl: bustUrl,
			  classification: data.classification,
			  confidence: typeof data.confidence === 'string' ? 
			   data.confidence : 
			   (parseFloat(data.confidence) * 100).toFixed(2) + '%',
			  tokenTicker: data.tokenTicker || 'N/A'
			};
			
			// Update the "current processing" display (only)
			if (currentProcessingImageEl.length) {
				imageInFlight = true;
			  // Preload image before updating anything
			  const img = new Image();
			  img.onload = function() {
			    // 1) Swap in the new image and text
			    currentProcessingImageEl.attr('src', bustUrl);
			    tokenAddressEl.text(data.tokenAddress || 'N/A');
			    classificationEl.text(data.classification);
			    confidenceEl.text((parseFloat(data.confidence) * 100).toFixed(2) + '%');
			    tokenTickerEl.text(data.tokenTicker || 'N/A');
			
			    // 2) Trigger a bullet-proof flash, and when it ends, flush any queued grid update
			    const flashOverlay = currentProcessingContainerEl.find('.flash-overlay');
			    if (flashOverlay.length) {
			      // mark that we're mid-flash
			      triggerYellowFlash(flashOverlay, () => {
			        // flash done → clear flag & run any pending grid update immediately
			        imageInFlight = false;
			        if (pendingGridUpdate) {
			          updateMultipleImagesDisplay();  // bypass throttle for the queued update
			          pendingGridUpdate = false;
			        }
			      });
			    } else {
			      // no overlay? just clear the flag
			      imageInFlight = false;
			    }
			  };
			  
			  // Handle image load errors gracefully
			  img.onerror = function() {
				console.error('Failed to load image:', bustUrl);
				imageInFlight = false;
				// Still update everything even on error
				currentProcessingImageEl.attr('src', bustUrl);
				tokenAddressEl.text(data.tokenAddress || 'N/A');
				classificationEl.text(data.classification);
				confidenceEl.text((parseFloat(data.confidence) * 100).toFixed(2) + '%');
				tokenTickerEl.text(data.tokenTicker || 'N/A');
			  };
			  
			  // Start loading the image
			  img.src = bustUrl;
			}
		  }
		  break;
		  
      case 'cat-dog-images-update':
	  memoryState.latestCatImages = data.catImages || [];
	  memoryState.latestDogImages = data.dogImages || [];

	  // 1) Store in localStorage for other pages
	  localStorage.setItem('latestCatImages', JSON.stringify(memoryState.latestCatImages));
	  localStorage.setItem('latestDogImages', JSON.stringify(memoryState.latestDogImages));
	  localStorage.setItem('lastCatDogFetchTime', String(Date.now()));

	  // 2) Then update the grid
	  if (imageInFlight) {
	    // we're mid-flash → defer until flashend
	    pendingGridUpdate = true;
	  } else {
	    // otherwise do the normal throttled update
	    updateMultipleImagesDisplayThrottled();
	  }
	  break;
	  
	  case 'counters-update':
      // If we received cat/dog/other counters
      if (typeof data.catCount === 'number') {
        counters.catCount = data.catCount;
        updateCounter(counters.catCount, 'counter1');
      }
      if (typeof data.dogCount === 'number') {
        counters.dogCount = data.dogCount;
        updateCounter(counters.dogCount, 'counter2');
      }
      if (typeof data.otherCount === 'number') {
        counters.otherCount = data.otherCount;
      }
      updateTotalImages();
      break;
		  
		// We ignore some message types we don't handle here
		case 'token-list-update':
		case 'vader-sentiment':
		case 'sentiment-history':
		case 'top-words-data':
		  break;
		  
		default:
		  console.warn('Unknown WebSocket message type:', data.type);
		  break;
		}
}
/* ------------------------------------------------------------------
   PART 4: PAGE LOAD & DROPDOWN HANDLING
   ------------------------------------------------------------------ */

$(document).ready(() => {
  // 1) Immediately initializeCatDogImages() 
  initializeCatDogImages();  

  // 2) Then counters, trending words, etc.
  initializeCounters();
  initializeTrendingWords();
  initializeCurrentProcessedImage();

  // 3) Finally set up WebSocket 
  initializeWebSocket();

  // 3) On tab focus, reload cat/dog if stale, plus counters, etc.
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
      const now = Date.now();
      if (now - lastCatDogFetchTime >= CAT_DOG_FETCH_INTERVAL_MS) {
      initializeCatDogImages();
      }
      initializeCounters();
      initializeTrendingWords();
      initializeCurrentProcessedImage();
    }
  });

  // 4) When user picks new grid size => do immediate layout update
  $('#box1').on('change', function() {
    catDisplayCount = parseInt(this.value, 10);
    updateGridLayoutImmediate(); // Force immediate re-render
  });

  $('#box2').on('change', function() {
    dogDisplayCount = parseInt(this.value, 10);
    updateGridLayoutImmediate(); // Force immediate re-render
  });

  // ── Mobile tap‑to‑cycle on #container1 ───────────────────────
  $('#container1').on('click', function() {
    if (window.innerWidth >= 1024) return;  // no‑op on desktop
    catState.index    = (catState.index + 1) % SIZES.length;
    catDisplayCount   = SIZES[catState.index];
    updateGridLayoutImmediate();
  });

  // ── Mobile tap‑to‑cycle on #container2 ───────────────────────
  $('#container2').on('click', function() {
    if (window.innerWidth >= 1024) return;
    dogState.index    = (dogState.index + 1) % SIZES.length;
    dogDisplayCount   = SIZES[dogState.index];
    updateGridLayoutImmediate();
  });
});