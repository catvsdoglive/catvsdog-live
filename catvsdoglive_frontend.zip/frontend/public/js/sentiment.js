"use strict";

/*
 * sentiment.js
 * ----------------------------------------------------------
 * This file handles the real-time sentiment updates via WebSocket:
 *   1) Requests a full state on connection, including sentiment data.
 *   2) Receives and processes 'vader-sentiment' messages to update
 *      the gauge needle, displayed compound value, and rolling text feed.
 *   3) Periodically updates aggregator data (oneMin, fifteenMin, etc.)
 *      based on 'sentiment-history' messages.
 *   4) Also handles 'top-words-data' to display top 1000 words in real time.
 *   5) On initial load, fetches top-words from /get-top-words over HTTP as well.
 * ----------------------------------------------------------
 */

$(document).ready(function () {
  // -------------------------------------
  // Part A: Immediately fetch top words once on page load (via HTTP)
  // -------------------------------------
  $.getJSON("/get-top-words")
    .done(function (response) {
      if (Array.isArray(response.words)) {
        // Now we have response.totalWords and response.uniqueWords too
        updateTopWords(response.words, response.totalWords, response.uniqueWords);
      }
    })
    .fail(function (err) {
      console.error("[sentiment.html] Error fetching top words (HTTP):", err);
    });


  // -------------------------------------
  // Part B: Fetch existing rolling-text lines (if any) on page load
  // -------------------------------------
  $.getJSON("/get-rolling-text")
    .done(function (response) {
      if (Array.isArray(response.rollingText)) {
        const container = document.getElementById("rollingTextContainer");
        // Load lines from oldest to newest or vice versa as you prefer
        // This example puts the *oldest* line at the bottom so the
        // *newest* ends up at the top:
        for (let i = response.rollingText.length - 1; i >= 0; i--) {
          addLineToRollingContainer(container, response.rollingText[i]);
        }
      }
    })
    .fail(function (err) {
      console.error("[sentiment.html] Error fetching rolling text:", err);
    });

// -------------------------------------
// Part C: Set up the WebSocket for real-time updates
// -------------------------------------
const ws = new WebSocket(location.protocol === 'https:' ? 
                         'wss://' + location.host + '/ws/' : 
                         'ws://' + location.host + '/ws/');

ws.onopen = () => {
  ws.send(JSON.stringify({ type: "request-full-state" }));
};

ws.onmessage = (event) => {
  try {
    const data = JSON.parse(event.data);

    switch (data.type) {

      case "full-state":
        // If the server includes sentimentHistory or topWords in 'full-state', update them here:
        if (data.sentimentHistory) {
          updateSentimentHistory({
            oneHour: data.sentimentHistory.oneHour || 0,
            fourHours: data.sentimentHistory.fourHours || 0,
            twelveHours: data.sentimentHistory.twelveHours || 0,
            twentyFourHour: data.sentimentHistory.twentyFourHour || 0,
            lifetimeAvg: data.sentimentHistory.lifetimeAvg || 0
          });
        }
        // Rest of case remains the same
        break;

      case "sentiment-history":
        // Update variable names in this handler too
        updateSentimentHistory(data);
        break;

      case "vader-sentiment":
        handleVaderSentiment(data);
        break;

      case "top-words-data":
        if (Array.isArray(data.words)) {
          // data.totalWords and data.uniqueWords might be numbers
          updateTopWords(data.words, data.totalWords, data.uniqueWords);
        }
        break;

      case "cat-dog-images-update":
        // Store cat/dog images in localStorage (no local display needed)
        localStorage.setItem("latestCatImages", JSON.stringify(data.catImages || []));
        localStorage.setItem("latestDogImages", JSON.stringify(data.dogImages || []));
        localStorage.setItem("lastCatDogFetchTime", String(Date.now()));
        break;

      default:
        // Ignore or handle other message types as needed
        break;
    }
  } catch (err) {
    console.error("[sentiment.html] Error parsing JSON from WS:", err);
  }
};

ws.onerror = (err) => {
  console.error("[sentiment.html] WebSocket error:", err);
};

ws.onclose = (evt) => {
  console.warn("[sentiment.html] WebSocket closed:", evt.code, evt.reason);
};

  // -------------------------------------
  // Functions for handling events/data
  // -------------------------------------

  // A) Appends a new line to rollingTextContainer with alternating color
  function addLineToRollingContainer(container, text) {
    const newLine = document.createElement("div");
    newLine.textContent = text;

    // Determine the color based on the number of existing lines
    const numLines = container.children.length;
    if (numLines % 2 === 0) {
      newLine.style.color = "#D8A4C0"; // Even lines
    } else {
      newLine.style.color = "#E2E2AA"; // Odd lines
    }

    // Insert new line at the top
    container.insertBefore(newLine, container.firstChild);
    container.scrollTop = 0;
  }

  // B) VADER sentiment message handler
  function handleVaderSentiment(data) {
    const compound = data.compound;
    let displayVal = (compound === 0) ? "0.0000" : compound.toFixed(4);
    if (compound > 0) {
      displayVal = `+${displayVal}`;
    }

    document.getElementById("compound-readout").textContent = `Sentiment: ${displayVal}`;
    updateGauge(compound);
    updateSentimentDescription(compound);

    // If there's analyzed text, add it to the rollingTextContainer
    if (data.analyzedText) {
      const container = document.getElementById("rollingTextContainer");
      addLineToRollingContainer(container, data.analyzedText);
    }
  }

  // C) Update aggregator-based sentiment metrics
	function updateSentimentHistory(historyData) {
	  const oneHourEl      = document.getElementById("sentiment-1hour");
	  const fourHoursEl    = document.getElementById("sentiment-4hours");
	  const twelveHoursEl  = document.getElementById("sentiment-12hours");
	  const twentyFourEl   = document.getElementById("sentiment-24hr");
	  const lifetimeEl     = document.getElementById("sentiment-lifetime");

	  const diff1HrEl      = document.getElementById("sentiment-1hour-diff");
	  const diff4HrEl      = document.getElementById("sentiment-4hours-diff");
	  const diff12HrEl     = document.getElementById("sentiment-12hours-diff");
	  const diff24HrEl     = document.getElementById("sentiment-24hr-diff");

	  const arrow1HrEl     = document.getElementById("sentiment-1hour-arrow");
	  const arrow4HrEl     = document.getElementById("sentiment-4hours-arrow");
	  const arrow12HrEl    = document.getElementById("sentiment-12hours-arrow");
	  const arrow24HrEl    = document.getElementById("sentiment-24hr-arrow");

	  const oneHourVal      = historyData.oneHour        || 0.0;
	  const fourHoursVal    = historyData.fourHours      || 0.0;
	  const twelveHoursVal  = historyData.twelveHours    || 0.0;
	  const twentyFourVal   = historyData.twentyFourHour || 0.0;
	  const lifetimeVal     = historyData.lifetimeAvg    || 0.0;

	  // Format and color partial windows
	  oneHourEl.textContent = oneHourVal >= 0 ? `+${oneHourVal.toFixed(3)}` : oneHourVal.toFixed(3);
	  oneHourEl.style.color = oneHourVal < 0 ? "red" : "#82A9D1";

	  fourHoursEl.textContent = fourHoursVal >= 0 ? `+${fourHoursVal.toFixed(3)}` : fourHoursVal.toFixed(3);
	  fourHoursEl.style.color = fourHoursVal < 0 ? "red" : "#B4D7FE";

	  twelveHoursEl.textContent = twelveHoursVal >= 0 ? `+${twelveHoursVal.toFixed(3)}` : twelveHoursVal.toFixed(3);
	  twelveHoursEl.style.color = twelveHoursVal < 0 ? "red" : "#B8D5A8";

	  twentyFourEl.textContent = twentyFourVal >= 0 ? `+${twentyFourVal.toFixed(3)}` : twentyFourVal.toFixed(3);
	  twentyFourEl.style.color = twentyFourVal < 0 ? "red" : "#D2A48C";

	  // Lifetime
	  lifetimeEl.textContent = lifetimeVal >= 0 ? `+${lifetimeVal.toFixed(3)}` : lifetimeVal.toFixed(3);

	  // Show difference from lifetime
	  function showDiff(diffElem, partialValue) {
		if (!diffElem) return;
		if (Math.abs(lifetimeVal) < 1e-8) {
		  diffElem.textContent = "(No % available)";
		  return;
		}
		const difference = partialValue - lifetimeVal;
		const pct = (difference / lifetimeVal) * 100;
		diffElem.textContent = `${pct >= 0 ? '+' : ''}${pct.toFixed(1)}% from avg`;
	  }

	  showDiff(diff1HrEl,   oneHourVal);
	  showDiff(diff4HrEl,   fourHoursVal);
	  showDiff(diff12HrEl,  twelveHoursVal);
	  showDiff(diff24HrEl,  twentyFourVal);

	  // Show arrow icons if partial > lifetime, < lifetime, or ~ same
	  function setArrow(arrowElem, partialVal, refVal) {
		if (!arrowElem) return;
		const epsilon = 1e-6;
		if (Math.abs(partialVal - refVal) < epsilon) {
		  arrowElem.textContent = "—";
		  arrowElem.style.color = "#999999";
		} else if (partialVal > refVal) {
		  arrowElem.textContent = "▲";
		  arrowElem.style.color = "#22c55e";
		} else {
		  arrowElem.textContent = "▼";
		  arrowElem.style.color = "red";
		}
	  }

	  setArrow(arrow1HrEl,    oneHourVal,     lifetimeVal);
	  setArrow(arrow4HrEl,    fourHoursVal,    lifetimeVal);
	  setArrow(arrow12HrEl,   twelveHoursVal,  lifetimeVal);
	  setArrow(arrow24HrEl,   twentyFourVal,   lifetimeVal);
	}

  // D) Rotate gauge needle based on compound value
  function updateGauge(compound) {
    const clamped = Math.max(-1, Math.min(1, compound));
    const angle = clamped * 110; // for a ~220° sweep
    document.getElementById("needle").setAttribute(
      "transform",
      `rotate(${angle})`
    );
  }

  // E) Display descriptive text for sentiment range
  function updateSentimentDescription(compound) {
    const descriptionEl = document.getElementById("sentiment-description");

    let description = "Neutral";
    if (compound >= 0.8) {
      description = "Extremely Positive";
    } else if (compound >= 0.6) {
      description = "Very Positive";
    } else if (compound >= 0.4) {
      description = "Positive";
    } else if (compound >= 0.2) {
      description = "Slightly Positive";
    } else if (compound > -0.2) {
      description = "Neutral";
    } else if (compound >= -0.4) {
      description = "Slightly Negative";
    } else if (compound >= -0.6) {
      description = "Negative";
    } else if (compound >= -0.8) {
      description = "Very Negative";
    } else {
      description = "Extremely Negative";
    }

    descriptionEl.textContent = description;
  }

  // F) Update the top words display in #topWordsContainer
  function updateTopWords(wordsArray, totalCount = 0, uniqueCount = 0) {
    const container = document.getElementById("topWordsContainer");
    container.innerHTML = ""; // Clear previous data

    if (!Array.isArray(wordsArray) || wordsArray.length === 0) {
      container.textContent = "No word data available.";
      return;
    }

    let textOutput = "";
    textOutput += `<div><span style="color: #FFF">Total Words: </span><span style="color: #E2E2AA">${totalCount}</span></div>`;
    textOutput += `<div><span style="color: #FFF">Total Unique Words: </span><span style="color: #E2E2AA">${uniqueCount}</span></div>`;
    textOutput += `<div><br></div>`; // blank line

    wordsArray.forEach((item, i) => {
      const rank = i + 1;
      textOutput += `<div><span style="color: #FFF">${rank}. ${item.word}: </span><span style="color: #D8A4C0">${item.freq}</span></div>`;
    });

    container.innerHTML = textOutput;
  }

});
