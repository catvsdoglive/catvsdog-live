"use strict";

/*
 * stream.js
 * ---------------------------------------------------------
 * Connects to a WebSocket server at ws://localhost:8765 to
 * receive real-time token list updates. Also fetches an
 * initial list of tokens via AJAX from /get-token-info.
 *
 * NOTE:
 *  - #loading is hidden once data is received.
 *  - #token-list is populated dynamically with token data.
 *  - #no-data is revealed if no tokens are returned.
 * ---------------------------------------------------------
 */

$(document).ready(function() {
  // Create the WebSocket connection
  const ws = new WebSocket(location.protocol === 'https:' ? 
                         'wss://' + location.host + '/ws/' : 
                         'ws://' + location.host + '/ws/');

  /*
   * updateTokenList(tokens):
   *  - Hides the loading indicator.
   *  - Clears and repopulates #token-list with token data.
   *  - If no tokens are found, shows #no-data instead.
   */
  function updateTokenList(tokens) {
    $('#loading').hide();

    const tokenList = $('#token-list');
    tokenList.empty();

    if (tokens && tokens.length > 0) {
      tokens.forEach((token, index) => {
        const hasDescription = token.description && token.description.trim().length > 0;
        const descriptionClass = hasDescription ? 'description' : 'description empty';

        // If this is the first token in the array, include a flash-overlay
        const flashOverlay = index === 0
          ? '<div class="flash-overlay flash-yellow"></div>'
          : '';

        // Construct the HTML element for each token
        const tokenElement = `
          <div class="token-container ${index === 0 ? 'first-token' : ''}">
            ${flashOverlay}
            <div class="token-info">
              <!-- Add mobile-friendly classes if needed -->
              <img src="${token.imageUrl}" alt="Token Image" class="token-image">
              <div class="token-details">
                <h3 class="text-white font-semibold token-name">${token.tokenNameAndTicker}</h3>
                <p class="${descriptionClass}">${token.description || ''}</p>
                <p class="classification-text">Class: ${token.class}</p>
              </div>
            </div>
          </div>
        `;
        tokenList.append(tokenElement);
      });
    } else {
      // If tokens array is empty or undefined, show #no-data
      $('#no-data').removeClass('hidden');
    }
  }

  /*
   * WebSocket 'onmessage' event:
   *  - Parses incoming data.
   *  - If 'cat-dog-images-update' => store arrays in localStorage.
   *  - If 'token-list-update' => call updateTokenList.
   */
  ws.onmessage = function(event) {
    try {
      const data = JSON.parse(event.data);

      // 1) If cat/dog images arrived, store them for main page or other subpages
      if (data.type === 'cat-dog-images-update') {
        localStorage.setItem('latestCatImages', JSON.stringify(data.catImages || []));
        localStorage.setItem('latestDogImages', JSON.stringify(data.dogImages || []));
        localStorage.setItem('lastCatDogFetchTime', String(Date.now()));
      }

      // 2) Existing logic for token-list updates
      if (data.type === 'token-list-update') {
        updateTokenList(data.tokens);
      }

    } catch (error) {
      console.error('Error handling WebSocket message:', error);
    }
  };

  /*
   * Initial AJAX request:
   *  - Fetches the token info from /get-token-info
   *  - On success, updates the token list
   *  - On error, displays a message in #no-data
   */
  $.ajax({
    url: '/get-token-info',
    method: 'GET',
    success: function(data) {
      updateTokenList(data);
    },
    error: function(xhr, status, error) {
      $('#loading').hide();
      $('#no-data').removeClass('hidden').text('Error loading token information');
      console.error('Error fetching token data:', error);
    }
  });
});
