"use strict"; // Enable strict mode

/*
 * script.js
 * -------------------------------------------------------------
 *  Orchestrates various frontend behaviors once the DOM is ready:
 *    - Loads text content into sections (using jQuery + DOMPurify).
 *    - Animates two "rectangle" elements with random wobbles,
 *      "sewing machine" effect, and directional stretching.
 *    - Implements smooth scrolling for nav links and dynamic
 *      styling for certain text highlights.
 *    - Sets up lazy-loading of Elon-themed images in a grid.
 *    - Updates metrics and a GMT time display on the page.
 *    - Handles navigation clicks to stream/generator pages.
 * -------------------------------------------------------------
 */

document.addEventListener("DOMContentLoaded", () => {
  // Scroll to top of the page when loaded
  window.scrollTo(0, 0);

  // Safely check if jQuery is available before using it
  if (typeof $ !== "undefined") {
    // Wrap in jQuery's ready as well, if needed:
    $(document).ready(function () {
      /*
       * rectangleTexts array: used to store lines for the animated rectangles.
       */
      let rectangleTexts = [];

      /**
       * applyDynamicStyles(targetElementSelector):
       *  - Styles specific elements within a container, such as .highlight,
       *    .chatgpt, .claude, adding colorPulse animations and more.
       */
      function applyDynamicStyles(targetElementSelector) {
        // Only apply these styles if the target container actually exists
        if ($(targetElementSelector).length) {
          // Style elements with class .highlight
          $(`${targetElementSelector} .highlight`).css({
            animation: "colorPulse 2s infinite ease-in-out",
            color: "#ff6347",
            fontWeight: "bold",
            position: "relative",
          });

          // Append an underline if not present
          if (
            $(`${targetElementSelector} .highlight`).find(".underline").length ===
            0
          ) {
            $(`${targetElementSelector} .highlight`).append(
              '<span class="underline"></span>'
            );
          }

          // Style references to ChatGPT
          $(`${targetElementSelector} .chatgpt`).css({
            fontWeight: "bold",
            color: "#61C497",
            textShadow: "0px 0px 5px rgba(87, 242, 135, 0.8)",
          });

          // Style references to Claude
          $(`${targetElementSelector} .claude`).css({
            fontWeight: "bold",
            color: "#A786DF",
            textShadow: "0px 0px 5px rgba(146, 121, 200, 0.8)",
          });
        }
      }

      // Define and inject dynamic keyframe animations into <style>, if not already injected
      const styleElement = document.createElement("style");
      styleElement.textContent = `
        /* Color pulsing animation */
        @keyframes colorPulse {
          0% {
            color: #ff6347; /* Lighter red */
            text-shadow: 0 0 5px rgba(255, 99, 71, 0.5);
          }
          50% {
            color: #ff4500; /* Darker red */
            text-shadow: 0 0 15px rgba(255, 69, 0, 1);
          }
          100% {
            color: #ff6347; /* Lighter red */
            text-shadow: 0 0 5px rgba(255, 99, 71, 0.5);
          }
        }

        /* Underline drawing animation */
        .highlight .underline {
          position: absolute;
          bottom: -5px; /* Adjust based on text size */
          left: 0;
          width: 100%;
          height: 2px;
          background: linear-gradient(to right, #ff6347, #ff4500);
          content: '';
          animation: underlineDraw 2s infinite;
        }

        @keyframes underlineDraw {
          0% {
            width: 0%;
          }
          100% {
            width: 100%;
          }
        }
      `;
      document.head.appendChild(styleElement);

      /**
       * loadContent(filePath, targetElementId):
       *  - Fetches text/html from filePath, sanitizes it, and inserts into targetElementId.
       *  - Then applies dynamic styles to the newly inserted content.
       */
      function loadContent(filePath, targetElementId) {
        // Only run if that target element actually exists on the page
        if (document.getElementById(targetElementId)) {
          $.get(filePath, function (data) {
            // Only sanitize if DOMPurify is available
            const sanitizedContent = window.DOMPurify
              ? DOMPurify.sanitize(data)
              : data;
            $(`#${targetElementId}`).html(sanitizedContent);

            // Apply special styling after content loads
            applyDynamicStyles(`#${targetElementId}`);
          }).fail(function (_, textStatus, errorThrown) {
            console.error(`Failed to load ${filePath}: ${textStatus}, ${errorThrown}`);
            $(`#${targetElementId}`).text("Failed to load content.");
          });
        }
      }

      /**
       * loadRectangleTexts(filePath, callback):
       *  - Loads lines from a text file into rectangleTexts.
       *  - If provided, calls callback() upon successful or failed load.
       */
      function loadRectangleTexts(filePath, callback) {
        // If we never have rectangle logic, we could skip—but let's keep it wrapped
        $.get(filePath, function (data) {
          const sanitizedContent = window.DOMPurify
            ? DOMPurify.sanitize(data)
            : data;
          rectangleTexts = sanitizedContent
            .split("\n")
            .filter((line) => line.trim() !== "");

          if (typeof callback === "function") {
            callback();
          }
        }).fail(function (_, textStatus, errorThrown) {
          console.error(`Failed to load ${filePath}: ${textStatus}, ${errorThrown}`);
          rectangleTexts = ["Fallback Text"];

          if (typeof callback === "function") {
            callback();
          }
        });
      }

      // -------------------------------------------------------------
      //  Load content for specific sections if they exist
      // -------------------------------------------------------------
      loadContent("content/about.txt", "section1-content");
      loadContent("content/section1.txt", "section2-content");
      loadContent("content/section2.txt", "section3-content");
      loadContent("content/marquee.txt", "scrolling-text-content");

      // Load rectangle texts from a file (for the rectangles)
      loadRectangleTexts("content/rectangle.txt");

      /**
       * Smooth scrolling for navigation <nav> anchor links, if such nav links exist
       */
      const navLinks = $("nav a");
      if (navLinks.length > 0) {
        navLinks.on("click", function (event) {
          event.preventDefault();
          const targetId = $(this).attr("href");
          const targetElement = $(targetId);

          if (targetElement.length) {
            const targetImage = targetElement.find("img");
            if (targetImage.length && !targetImage[0].complete) {
              // If an image is present but not yet loaded, wait for it
              targetImage.on("load", function () {
                scrollToSection(targetElement);
              });
            } else {
              scrollToSection(targetElement);
            }
          }
        });
      }

      /**
       * scrollToSection(targetElement):
       *  - Animate scroll to the offset top minus 80px for a header margin.
       */
      function scrollToSection(targetElement) {
        const scrollToPosition = targetElement.offset().top - 80;
        $("html, body").animate({ scrollTop: scrollToPosition }, 1000);
      }

		/**
		 * Load Elon-themed images in a grid (#image-grid) with standard, immediate loading.
		 */
		const elonImages = [
		  "images/elonpump.png",
		  "images/elonmeme1.png",
		  "images/eloncatdog.png",
		  "images/elonmeme2.png",
		  "images/eloncode.png",
		  "images/elonmeme3.png",
		];
		const $imageGrid = $("#image-grid");

		if ($imageGrid.length > 0) {
		  // Only run if #image-grid is present
		  elonImages.forEach(function (imagePath) {
			// Create a container with a normal src (no lazy loading)
			const container = $(`
			  <div class="relative aspect-w-1 aspect-h-1">
				<img
				  src="${imagePath}"
				  alt="Elon Image"
				  class="object-fill w-full h-full rounded-lg opacity-0 transition-opacity duration-500"
				>
			  </div>
			`);

			// Optional: fade in when the image finishes loading
			container.find("img").on("load", function() {
			  $(this).removeClass("opacity-0");
			});

			$imageGrid.append(container);
		  });
		}

		/**
		 * updateImage(containerId, imageUrl):
		 *  - Fades out an image, updates its src, then fades it back in.
		 */
		function updateImage(containerId, imageUrl) {
		  const $imgElement = $(`#${containerId}`);
		  if ($imgElement.length) {
			$imgElement.fadeOut(100, function () {
			  // Prevent browser caching by appending ?v=timestamp
			  $imgElement
				.attr("src", `${imageUrl}?v=${new Date().getTime()}`)
				.fadeIn(100);
			});
		  } else {
			console.error(`Image element not found in ${containerId}`);
		  }
		}

      /*
       * Rectangle animation setup: wobble, sewing machine effect, directional stretching
       */
      const $rectangle1 = $("#rectangle1");
      const $rectangle2 = $("#rectangle2");

      // If either rectangle is missing, skip the entire rectangle animation logic
      if ($rectangle1.length && $rectangle2.length) {
        // Potential background colors for the rectangles
		const colors = [
			"#B4D7FE", // Light Blue (attribute-name)
			"#B8D5A8", // Soft Green (number)
			"#D2A48C", // Warm Brown (string)
			"#D8A4C0", // Pinkish Mauve (keyword)
			"#E2E2AA", // Pale Yellow (function)
		];

        // Array of emojis used in rectangle text
        const emojis = [
          "🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼","🐨","🐯","🦁","🐮","🐷","🐸",
          "🐵","🐔","🐧","🐦","🐤","🦆","🐝","🐛","🦋","🐌","🐞","🐢","🐍","🦎",
          "🐙","🦑","🐠","🐳","🦈","🐊","🐘","🦏","🦒","🦘","🐫","🦓","🚗","🚕",
          "🚙","🚌","🚎","🏎️","🚓","🚑","🚒","🚜","🚲","🛴","🚀","🛸","✈️","🚁",
          "🍏","🍎","🍐","🍊","🍋","🍌","🍉","🍇","🍓","🍒","🍑","🍍","🥭","🥥",
          "🥑","🥦","🥕","🌽","🌶️","🍅","🥔","🥐","🍞","🥖","🥨","🧀","🥚","🍳",
          "🥞","🥓","🍔","🍟","🍕","🌭","🌮","🌯","🥪","🥙","🍝","🍜","🍣","🍤",
          "🍪","🍩","🍰","🎂","🍦","🍧","🍨","🍿","🍫","🍬","🍭","☕","🍵","🍺",
          "🍻","🍷","🥂","🍾","🏳️","🏴","🏁","🚩","🏳️‍🌈","🏳️‍⚧️","🇺🇸","🇬🇧",
          "🇨🇦","🇦🇺","🎈","🎉","🎊","🎁","📚","📖","🎨","🎬","🎤","🎧","🎹","🥁",
          "🎷","🎺","🎸","📷","📹","🎥","📺","📱","💻","⌨️","🖱️","💡","🔑","🔨",
          "⚙️","🛠️","🔧","💰","💎","🧸","🔒","🔓","🧭","⏰","🛎️","🚪","🛏️","🛋️",
          "🚿","🛁","🚽","🧻","🪑","🛒","🎀","🎗️","🏆","🎮"
        ];

        let sewingMachineActive = false;
        let sewingMachineInterval;

        // Initialize transform data
        $rectangle1.data("translateX", 0);
        $rectangle1.data("scaleX", 1);
        $rectangle2.data("translateX", 0);
        $rectangle2.data("scaleX", 1);

        /**
         * updateTransform($rect):
         *  - Applies translateX/scaleX values stored in $rect's data attributes.
         */
        function updateTransform($rect) {
          const translateX = $rect.data("translateX") || 0;
          const scaleX = $rect.data("scaleX") || 1;
          $rect.css("transform", `translateX(${translateX}px) scaleX(${scaleX})`);
        }

        /**
         * randomWobble($rect, $otherRect):
         *  - Produces either a standard wobble or a "sewing machine" effect
         *    of rapid small movements.
         */
        function randomWobble($rect, $otherRect) {
          if (sewingMachineActive) {
            // Quick small movements
            const wobbleDistance = Math.floor(Math.random() * 5) - 2;
            $rect.css("transition", "transform 0.02s linear");
            $rect.data("translateX", wobbleDistance);
          } else {
            // Standard wobble
            const wobbleDistance = Math.floor(Math.random() * 41) - 20;
            $rect.css("transition", "transform 0.05s linear");
            $rect.data("translateX", wobbleDistance);

            // Slight push on the other rectangle
            const pushDistance = Math.floor(Math.random() * 21) - 10;
            $otherRect.css("transition", "transform 0.05s linear");
            $otherRect.data("translateX", pushDistance);
            updateTransform($otherRect);
          }
          updateTransform($rect);
        }

        /**
         * randomColorChange($rect):
         *  - Assign a random background color from the colors array.
         */
        function randomColorChange($rect) {
          const color = colors[Math.floor(Math.random() * colors.length)];
          $rect.css("background-color", color);
        }

        /**
         * animateRectangle($rect, $otherRect):
         *  - Changes color, applies wobble, and updates text with an emoji + line
         *    from rectangleTexts.
         */
        function animateRectangle($rect, $otherRect) {
          if ($rect.is(":visible")) {
            randomColorChange($rect);
            randomWobble($rect, $otherRect);

            if (rectangleTexts.length > 0) {
              const randomIndex = Math.floor(Math.random() * rectangleTexts.length);
              const newText = rectangleTexts[randomIndex] || "";
              const emojiIndex = Math.floor(Math.random() * emojis.length);
              const randomEmoji = emojis[emojiIndex] || "";
              $rect.html(`${randomEmoji} ${newText}`.trim());
            } else {
              $rect.html("🎉 Default Text");
            }
          }
        }

        /**
         * Loops to animate left rectangle
         */
        function animateRectangle1() {
          animateRectangle($rectangle1, $rectangle2);

          // Random delay
          let randomDelay;
          if (Math.random() < 0.05) {
            randomDelay = Math.floor(Math.random() * 300) + 500;
          } else {
            randomDelay = Math.floor(Math.random() * 150) + 50;
          }
          setTimeout(animateRectangle1, randomDelay);
        }

        /**
         * Loops to animate right rectangle
         */
        function animateRectangle2() {
          animateRectangle($rectangle2, $rectangle1);

          let randomDelay;
          if (Math.random() < 0.05) {
            randomDelay = Math.floor(Math.random() * 400) + 500;
          } else {
            randomDelay = Math.floor(Math.random() * 150) + 50;
          }
          setTimeout(animateRectangle2, randomDelay);
        }

        // Start both rectangle animation loops
        animateRectangle1();
        animateRectangle2();

        /**
         * startSewingMachineEffect():
         *  - Periodically triggers a "sewing machine" mode
         *    of quick small movements for about 1s.
         */
        function startSewingMachineEffect() {
          setInterval(function () {
            sewingMachineActive = true;
            const sewingDuration = 1000;

            clearInterval(sewingMachineInterval);
            sewingMachineInterval = setInterval(function () {
              randomWobble($rectangle1, $rectangle2);
              randomWobble($rectangle2, $rectangle1);
            }, 20);

            setTimeout(function () {
              sewingMachineActive = false;
              clearInterval(sewingMachineInterval);
            }, sewingDuration);
          }, Math.random() * 10000 + 5000);
        }

        /**
         * startDirectionalStretchingEffect($rect, direction):
         *  - Occasionally stretches a rectangle horizontally
         *    from either left or right, then shrinks back.
         */
        function startDirectionalStretchingEffect($rect, direction) {
          setInterval(function () {
            const stretchAmount = 1.1;
            $rect.css("transition", "transform 0.3s ease-in-out");

            if (direction === "left") {
              $rect.css("transform-origin", "left center");
            } else {
              $rect.css("transform-origin", "right center");
            }

            $rect.data("scaleX", stretchAmount);
            updateTransform($rect);

            setTimeout(function () {
              $rect.data("scaleX", 1);
              updateTransform($rect);
            }, 500);
          }, Math.random() * 15000 + 5000);
        }

        // Activate sewing machine and stretching effects
        startSewingMachineEffect();
        startDirectionalStretchingEffect($rectangle1, "right");
        startDirectionalStretchingEffect($rectangle2, "left");
      } // end if ($rectangle1.length && $rectangle2.length)

      /**
       * handleScroll():
       *  - Hides rectangles if user has scrolled down,
       *    sets navbars to "fixed" on desktop once scrolling begins, etc.
       */
      function handleScroll() {
        // Hide rectangle-container on scroll if they exist
        const $rectContainer = $(".rectangle-container");
        if ($rectContainer.length) {
          if ($(window).scrollTop() > 0) {
            $rectContainer.css("opacity", 0);
          } else {
            $rectContainer.css("opacity", 1);
          }
        }

        const isDesktop = $(window).width() > 1367;
        const $navbarsContainer = $(".navbars-container");
        const $mainContent = $(".main-content");
        if ($navbarsContainer.length && $mainContent.length) {
          if (isDesktop) {
            if ($(window).scrollTop() > 0) {
              $navbarsContainer.addClass("fixed");
              $mainContent.css("padding-top", $navbarsContainer.outerHeight());
            } else {
              $navbarsContainer.removeClass("fixed");
              $mainContent.css("padding-top", "");
            }
          } else {
            $navbarsContainer.removeClass("fixed");
            $mainContent.css("padding-top", "");
          }
        }
      }

      // Initial call, then bind events
      handleScroll();
      $(window).on("scroll", handleScroll);
      $(window).on("resize", handleScroll);
    });
  } // end if (typeof $ !== "undefined")

  /*
   * Navigation to stream.html or generator.html
   * from #stream, #generator
   */
  const streamLink = document.getElementById("stream");
  if (streamLink) {
    streamLink.addEventListener("click", function (e) {
      e.preventDefault();
      window.location.href = "stream.html";
    });
  }

  const generatorLink = document.getElementById("generator");
  if (generatorLink) {
    generatorLink.addEventListener("click", function (e) {
      e.preventDefault();
      window.location.href = "generator.html";
    });
  }

  // Scroll to top when the #button is clicked
  const topButton = document.getElementById("button");
  if (topButton) {
    topButton.addEventListener("click", function () {
      // If jQuery is available, do a smooth scroll
      if (typeof $ !== "undefined") {
        $("html, body").animate({ scrollTop: 0 }, 1000);
      } else {
        // fallback
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    });
  }

  /**
   * Display certain model metrics if their elements exist
   */
  const metrics = {
    accuracy: "98.82%",
    precision: "98.10%",
    recall: "98.04%",
    f1score: "98.06%",
    models: "ResNet50, ResNet101, Resnet152",
  };

  for (const [id, value] of Object.entries(metrics)) {
    const element = document.getElementById(id);
    if (element) {
      element.innerText = value;
    } else {
      // Not all pages will have these elements
      // console.warn(`Element with ID '${id}' not found.`);
    }
  }

  /**
   * Update GMT time in #gmt-time every second
   */
  function updateTime() {
    const now = new Date();
    const gmtElement = document.getElementById("gmt-time");
    if (gmtElement) {
      gmtElement.innerText = now.toUTCString();
    }
  }
  // Initialize and then refresh every second (only if #gmt-time is present)
  if (document.getElementById("gmt-time")) {
    updateTime();
    setInterval(updateTime, 1000);
  }
});
