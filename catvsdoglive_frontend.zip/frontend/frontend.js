/**
 * -----------------------------------------------------------------------------
 * FRONTEND.JS - PURPOSE & FUNCTIONALITY
 * -----------------------------------------------------------------------------
 * 
 * This Node.js file acts as a proxy between the backend and the browser.
 * It provides:
 * 
 *   1) Express HTTP Server:
 *      - Serves static files (HTML, CSS, JS) from a designated public directory.
 *      - Offers REST API endpoints (e.g., /get-counters, /get-trending-words)
 *        that return in-memory state for the client.
 * 
 *   2) WebSocket Server for Browser Clients:
 *      - Listens on FRONTEND_WS_PORT for incoming browser connections.
 *      - Maintains a set of connected clients and broadcasts backend updates.
 *      - Responds to client requests (e.g., "request-full-state") with a full
 *        snapshot of counters, trending words, sentiment, etc.
 * 
 *   3) WebSocket Client to the Backend:
 *      - Connects to BACKEND_WS_URL with an appended API key to receive live updates.
 *      - Maintains in-memory state for counters, trending words, token info, and sentiment.
 *      - Includes reconnection logic to maintain backend connectivity.
 * 
 *   4) Graceful Startup & Shutdown:
 *      - Sets up web servers, periodic tasks (e.g. heartbeats), and signal listeners
 *        (SIGINT, SIGTERM) for a clean shutdown.
 * 
 * Security Enhancements:
 *   - Enforces CORS restrictions using allowed origins from CORS_ORIGIN.
 *   - Applies rate limiting on API endpoints.
 *   - Secures backend WebSocket connections with an API key.
 *   - Utilizes HTTPS/WSS for secure production communication.
 * -----------------------------------------------------------------------------
 */

// Load required modules.
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const { spawn } = require("child_process");

// Load environment variables from the .env file.
require('dotenv').config({ path: path.join(__dirname, '.env') });

const express = require('express');
const WebSocket = require('ws');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');

// Use production settings directly.
const API_KEY = process.env.API_KEY_PROD;
const BACKEND_WS_URL = process.env.BACKEND_WS_URL + '?api_key=' + API_KEY;

// Server port and directory configuration.
const PORT = parseInt(process.env.FRONTEND_PORT) || 3000;
const FRONTEND_WS_PORT = parseInt(process.env.FRONTEND_WS_PORT) || 8765;
const PUBLIC_DIR = path.resolve(__dirname, process.env.PUBLIC_DIR);

// Create the Express application.
const app = express();
app.set('trust proxy', '127.0.0.1');

const allowedOrigins = process.env.CORS_ORIGIN.split(',').map(origin => origin.trim());

// Map to store client state request timestamps.
const clientStateRequests = new Map();

// Rate-limit window and cleanup cadence
const CLIENT_STATE_WINDOW_MS = 60 * 1000;   // 1 minute window
// Periodic pruning interval (5 windows). Keys with only stale times are dropped.
const CLIENT_STATE_PRUNE_EVERY_MS = CLIENT_STATE_WINDOW_MS * 5;

const imagePredictionQueue = [];
let isImagePredictionProcessing = false;

// -----------------------------------------------------------------------------
// Dynamic Content Security Policy (CSP) using Helmet
// -----------------------------------------------------------------------------
const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: [
    "'self'",
    "https://cdnjs.cloudflare.com",
    "https://cdn.jsdelivr.net"
  ],
  styleSrc: ["'self'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com", "'unsafe-inline'"],
  imgSrc: [
    "'self'",
    "data:",
    "https://catvsdog.live",
    "https://www.catvsdog.live",
    "https://catvsdog.live/images/",
    "https://catvsdog.live/images/backend/"
  ],
  fontSrc: ["'self'", "https://fonts.googleapis.com", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
  objectSrc: ["'none'"],
  workerSrc: ["'self'", "blob:"],
  frameAncestors: ["'self'"],
  baseUri: ["'self'"],
  formAction: ["'self'"],
  connectSrc: [
    "'self'",
    "wss://catvsdog.live",
    "https://catvsdog.live",
    "wss://catvsdog.live:8765",
    "data:",
    "wss://catvsdog.live/ws/",
    "https://catvsdog.live/ws/",
    "wss://catvsdog.live:*"
  ]
};

app.use(
  helmet({
    contentSecurityPolicy: { 
      directives: cspDirectives,
      useDefaults: false
    },
    frameguard: { action: 'deny' },
    hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    xssFilter: true
  })
);

// -----------------------------------------------------------------------------
// CORS Configuration
// -----------------------------------------------------------------------------
app.use(
  cors({
    origin: function (origin, callback) {
      // Allow requests with no origin (like mobile apps or curl requests)
      if (!origin) return callback(null, true);
      if (allowedOrigins.indexOf(origin) !== -1) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    methods: 'GET,POST',
    allowedHeaders: 'Content-Type,Authorization'
  })
);

// -----------------------------------------------------------------------------
// Rate Limiting
// -----------------------------------------------------------------------------
const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: parseInt(process.env.API_RATE_LIMIT) || 100,
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', apiLimiter);
app.use('/login', apiLimiter);

// ----------------------------------------------------------------------------
// Backend Reconnection and Application State Variables
// ----------------------------------------------------------------------------
const MAX_RECONNECT_ATTEMPTS = 30;
const INITIAL_RECONNECT_DELAY = 1000; // ms
const MAX_RECONNECT_DELAY = 60000;    // ms
let reconnectAttempt = 0;
let reconnectTimer = null;

let currentCounters = { catCount: 0, dogCount: 0, otherCount: 0 };
let currentTokens = [];
let currentTrendingWords = Array(9).fill('N/A');
let processingToken = {
  tokenAddress: 'N/A',
  imageUrl: null,
  classification: 'N/A',
  confidence: 'N/A',
  tokenTicker: 'N/A'
};
let currentSentiment = {
  oneHour: 0.0,
  fourHours: 0.0,
  twelveHours: 0.0,
  twentyFourHour: 0.0,
  lifetimeAvg: 0.0
};

let topWordData = [];
let totalWordCount = 0;
let uniqueWordCount = 0;
let currentGeneratedNames = [];
let currentRollingText = [];
let currentCatImages = [];
let currentDogImages = [];

// ----------------------------------------------------------------------------
// REST API Endpoints
// ----------------------------------------------------------------------------
app.get('/get-counters', (req, res) => {
  res.json(currentCounters);
});

app.get('/get-trending-words', (req, res) => {
  res.json({ words: currentTrendingWords });
});

app.get('/get-token-info', (req, res) => {
  if (currentTokens.length > 0) {
    res.json(currentTokens);
  } else {
    res.status(404).json({ error: 'No token information available yet.' });
  }
});

app.get('/get-cat-dog-images', (req, res) => {
  res.json({
    catImages: currentCatImages,
    dogImages: currentDogImages,
  });
});

app.get('/get-current-processing-image', (req, res) => {
  res.json(processingToken);
});

app.get('/get-top-words', (req, res) => {
  res.json({
    totalWords: totalWordCount,
    uniqueWords: uniqueWordCount,
    words: topWordData
  });
});

app.get('/get-generated-names', async (req, res) => {
  if (currentGeneratedNames.length === 0) {
    console.log("[frontend.js] currentGeneratedNames is empty; generating anew...");
    try {
      await runWordGeneratorAsync();
      return res.json({ names: currentGeneratedNames });
    } catch (error) {
      console.error("[frontend.js] word_generator.py error:", error);
      return res.status(500).json({ error: "Failed to generate names" });
    }
  } else {
    console.log(`[frontend.js] Returning ${currentGeneratedNames.length} existing generated names.`);
    res.json({ names: currentGeneratedNames });
  }
});

app.get('/get-rolling-text', (req, res) => {
  res.json({ rollingText: currentRollingText });
});

/* ------------------------------------------------------------------
   SINGLE‑WORKER TTS SCHEDULER
   ------------------------------------------------------------------ */
let ttsBusy        = false;   // true while a child process is running
let ttsNextPayload = null;    // holds the most recent words array

function scheduleTTS(wordsArray) {
  ttsNextPayload = wordsArray;
  if (ttsBusy) return;

  (async function runTtsJob () {
    const payload = ttsNextPayload;
    ttsNextPayload = null;
    ttsBusy = true;

    try {
      await spawnTTS(payload);
      console.log('[TTS] done for:', payload.slice(0, 3).join(', '));
    } catch (err) {
      console.warn('[TTS] failed:', err.message);
    } finally {
      ttsBusy = false;
      if (ttsNextPayload) runTtsJob();
    }
  })();
}

// ----------------------------------------------------------------------------
// Helper Functions
// 
const MAX_RETRIES = 3;

function markRetry(message) {
  try {
    const data = JSON.parse(message);
    data._retryCount = (data._retryCount || 0) + 1;
    return JSON.stringify(data);
  } catch (err) {
    console.error('[Retry] Error marking retry count:', err);
    return message; // Return original if parsing fails
  }
}

function getRetryCount(message) {
  try {
    return JSON.parse(message)._retryCount || 0;
  } catch {
    return 0;
  }
}

// ----------------------------------------------------------------------------
// Helper Functions (TTS, Rolling Text, etc.)
// ----------------------------------------------------------------------------
async function spawnTTS(wordsArray) {
  const pythonExec = '/home/www-data/venv/bin/python';
  const scriptPath = path.join(__dirname, 'generate_tts.py');
  const tempFile = path.join(os.tmpdir(), `tts_words_${Date.now()}.json`);

  // Write JSON asynchronously to avoid blocking the event loop
  let fileWritten = false;
  try {
    await fsp.writeFile(tempFile, JSON.stringify(wordsArray), 'utf8');
    fileWritten = true;
    console.log(`[TTS] Words saved to ${tempFile}`);
  } catch (err) {
    console.error(`[TTS] Error writing temp file: ${err.message}`);
  }

  // Spawn Python TTS (child process does the heavy work)
  const args = fileWritten ? [scriptPath, '--file', tempFile]
                           : [scriptPath, wordsArray.join(' ')];
  const pyProcess = spawn(pythonExec, args);

  let stdoutData = '';
  let stderrData = '';

  pyProcess.stdout.on('data', (data) => {
    stdoutData += data.toString();
    console.log(`[TTS] stdout: ${data.toString().trim()}`);
  });

  pyProcess.stderr.on('data', (data) => {
    stderrData += data.toString();
    console.error(`[TTS] stderr: ${data.toString().trim()}`);
  });

  return await new Promise((resolve, reject) => {
    pyProcess.on('exit', (code) => {
      // Clean up temp file asynchronously
      if (fileWritten) {
        fsp.unlink(tempFile).catch(() => {});
      }
      if (code === 0) {
        console.log('[TTS] trending-words-latest.wav generated successfully.');
        resolve();
      } else {
        console.error(`[TTS] generate_tts.py exited code: ${code}`);
        console.error(`[TTS] stdout: ${stdoutData}`);
        console.error(`[TTS] stderr: ${stderrData}`);
        reject(new Error(`TTS script error (code ${code})`));
      }
    });
    pyProcess.on('error', (err) => {
      if (fileWritten) {
        fsp.unlink(tempFile).catch(() => {});
      }
      console.error('[TTS] Error spawning Python script:', err);
      reject(err);
    });
  });
}

function addRollingText(newText) {
  const MAX_LINES = 100;
  currentRollingText.unshift(newText);
  if (currentRollingText.length > MAX_LINES) {
    currentRollingText.pop();
  }
}

// ----------------------------------------------------------------------------
// Express Static and 404 Handler
// ----------------------------------------------------------------------------
app.use(express.static(PUBLIC_DIR));
app.use('/images', express.static('/var/www/frontend/public/images'));
app.use('/images/backend', express.static('/var/www/backend/token_images'));
app.use((req, res) => {
  res.status(404).sendFile(path.join(PUBLIC_DIR, '404.html'));
});

// ----------------------------------------------------------------------------
// WebSocket Server for Browser Clients
// ----------------------------------------------------------------------------
let frontendWebSocketServer = null;
let frontendUIClients = new Set();

function broadcastToFrontendUIClients(message) {
  let successCount = 0;
  let failureCount = 0;
  
  frontendUIClients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      try {
        client.send(message, { binary: false }, (err) => {
          if (err) {
            failureCount++;
            console.warn('Error sending to frontend client:', err.message);
          } else {
            successCount++;
          }
        });
      } catch (err) {
        failureCount++;
        console.error('Exception sending to frontend client:', err.message);
      }
    }
  });
  
  // Log only if there were failures
  if (failureCount > 0) {
    console.warn(`[Broadcast] Stats - Success: ${successCount}, Failed: ${failureCount}`);
  }
}

function broadcastTopWords(total, unique, topWordsArray) {
  const msg = JSON.stringify({
    type: 'top-words-data',
    totalWords: total,
    uniqueWords: unique,
    words: topWordsArray
  });
  frontendUIClients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(msg, { binary: false }, err => {
        if (err) console.warn('Error sending top words data:', err.message);
      });
    }
  });
}

function safeSpawn(command, args, options = {}) {
  console.log(`[SPAWN] Starting process: ${command} ${args.join(' ')}`);
  const child = spawn(command, args, options);
  
  // Log PID for debugging
  console.log(`[SPAWN] Child process started with PID ${child.pid}`);
  
  // Complete set of handlers
  child.on('exit', (code, signal) => {
    console.log(`[SPAWN] Child PID ${child.pid} exited with code ${code}, signal ${signal}`);
  });
  
  child.on('close', (code, signal) => {
    console.log(`[SPAWN] Child PID ${child.pid} closed with code ${code}, signal ${signal}`);
  });
  
  child.on('error', (err) => {
    console.error(`[SPAWN] Child PID ${child.pid} error:`, err);
  });
  
  return child;
}

function runWordCounter() {
  console.log("[frontend.js] Running word_counter.py ...");
  analyticsJobRunning = true;
  lastJobType = "counter";
  
  // Set a safety timeout to reset status after 5 minutes
  clearAnalyticsTimeout();
  analyticsJobTimeout = setTimeout(() => {
    console.log("[frontend.js] Analytics job safety timeout triggered");
    resetAnalyticsJobStatus();
  }, 5 * 60 * 1000);
  
  const pyProcess = safeSpawn("/home/www-data/venv/bin/python", ["word_counter.py"]);

  let pyOutput = "";
  pyProcess.stdout.on("data", (data) => {
    pyOutput += data.toString();
  });

  pyProcess.stderr.on("data", (errData) => {
    console.error("[frontend.js] word_counter.py error:", errData.toString());
  });

  pyProcess.on("close", (code) => {
    console.log(`[frontend.js] word_counter.py exited with code ${code}`);
    resetAnalyticsJobStatus();
    
    // Process output
    const lines = pyOutput.trim().split('\n');
    const jsonLine = lines[lines.length - 1];
    try {
      const parsed = JSON.parse(jsonLine);
      totalWordCount = parsed.totalWords || 0;
      uniqueWordCount = parsed.uniqueWords || 0;
      topWordData = parsed.topWords || [];
      broadcastTopWords(totalWordCount, uniqueWordCount, topWordData);
    } catch (err) {
      console.error("[frontend.js] Failed to parse word_counter.py JSON:", err.message);
    }
  });
}

function runWordGeneratorAsync() {
  return new Promise((resolve, reject) => {
    console.log("[frontend.js] Running word_generator.py (async) ...");
    analyticsJobRunning = true;
    lastJobType = "generator";
    
    // Set a safety timeout to reset status after 5 minutes
    clearAnalyticsTimeout();
    analyticsJobTimeout = setTimeout(() => {
      console.log("[frontend.js] Analytics job safety timeout triggered");
      resetAnalyticsJobStatus();
      reject(new Error("Analytics job timed out"));
    }, 5 * 60 * 1000);
    
    const pyProcess = safeSpawn("/home/www-data/venv/bin/python", ["word_generator.py"], {
      cwd: path.join(__dirname)
    });

    let pyOutput = "";
    pyProcess.stdout.on("data", (data) => {
      pyOutput += data.toString();
    });

    pyProcess.stderr.on("data", (errData) => {
      console.error("[frontend.js] word_generator.py error:", errData.toString());
    });

    pyProcess.on("close", (code) => {
      console.log(`[frontend.js] word_generator.py exited with code ${code}`);
      resetAnalyticsJobStatus();
      
      parseWordGeneratorOutput(pyOutput);
      resolve();
    });

    pyProcess.on("error", (err) => {
      resetAnalyticsJobStatus();
      reject(err);
    });
  });
}

let analyticsJobRunning = false;
let lastJobType = null;
let analyticsJobTimeout = null;

function clearAnalyticsTimeout() {
  if (analyticsJobTimeout) {
    clearTimeout(analyticsJobTimeout);
    analyticsJobTimeout = null;
  }
}

function resetAnalyticsJobStatus() {
  analyticsJobRunning = false;
  clearAnalyticsTimeout();
}

function scheduleNextAnalyticsJob() {
  if (analyticsJobRunning) {
    // If a job is running, check back in 10 seconds
    setTimeout(scheduleNextAnalyticsJob, 10 * 1000);
    return;
  }
  
  // Choose which job to run next, alternating between counter and generator
  const nextJobType = (lastJobType === "counter") ? "generator" : "counter";
  
  if (nextJobType === "counter") {
    runWordCounter();
  } else {
    runWordGeneratorAsync()
      .then(() => {
        console.log('[frontend.js] Successfully generated names.');
      })
      .catch((err) => {
        console.error('[frontend.js] Failed to generate names:', err);
      });
  }
  
  // Schedule next check
  setTimeout(scheduleNextAnalyticsJob, 60 * 1000);
}

function parseWordGeneratorOutput(output) {
  const lines = output.trim().split("\n");
  let startIndex = lines.findIndex(line => line.includes("Generated names:"));
  if (startIndex === -1) {
    console.error("[frontend.js] Could not find 'Generated names:' marker in output");
    return;
  }
  currentGeneratedNames = [];
  for (let i = startIndex + 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    currentGeneratedNames.push(line);
  }
  console.log(`[frontend.js] Stored ${currentGeneratedNames.length} new generated names.`);
}

// ----------------------------------------------------------------------------
// Frontend WebSocket Server for UI Clients
// ----------------------------------------------------------------------------
function startFrontendWebSocketServer() {
  const wssFrontend = new WebSocket.Server({ port: FRONTEND_WS_PORT }, () => {
    console.log(`Frontend WebSocket server started on port ${FRONTEND_WS_PORT}`);
  });
  frontendWebSocketServer = wssFrontend;

  wssFrontend.on('connection', (ws, req) => {
    frontendUIClients.add(ws);
	const clientIp = req.socket.remoteAddress;
    ws.on('message', (message) => {
      let data;
      try {
        data = JSON.parse(message);
      } catch (err) {
        console.error('[frontend.js] Error parsing message from UI:', err);
        return;
      }
      if (data.type === 'request-full-state') {
        const now = Date.now();
        const requestTimes = clientStateRequests.get(clientIp) || [];
        const recentRequests = requestTimes.filter(time => now - time < CLIENT_STATE_WINDOW_MS);
        if (recentRequests.length >= 5) {
          console.warn(`[frontend.js] Client ${clientIp} requesting state too frequently`);
          return;
        }
        recentRequests.push(now);
        clientStateRequests.set(clientIp, recentRequests);
        if (backendWs && backendWs.readyState === WebSocket.OPEN) {
          console.log('[frontend.js] Forwarding request-full-state to backend...');
          backendWs.send(JSON.stringify({ type: 'request-full-state' }));
        }
      }
    });
    ws.on('close', (code, reason) => {
      frontendUIClients.delete(ws);
      console.log(`Frontend UI client disconnected. Code: ${code}, Reason: ${reason}`);
	  // Opportunistic prune for this IP if all timestamps are stale
      const times = clientStateRequests.get(clientIp);
      if (times && times.every(t => (Date.now() - t) >= CLIENT_STATE_WINDOW_MS)) {
      clientStateRequests.delete(clientIp);
      }
    });
    ws.on('error', (error) => {
      frontendUIClients.delete(ws);
      console.error('Frontend UI client error:', error.message);
    });
  });
}



// ----------------------------------------------------------------------------
// WebSocket Client to Backend
// ----------------------------------------------------------------------------
let backendWs = null;
let isBackendConnected = false;
let isShuttingDown = false;

const MESSAGE_QUEUE_SIZE = 1000;
const messageQueue = [];
let isProcessingQueue = false;

function queueBackendMessage(message) {
  try {
    const parsed = JSON.parse(message);
    
    if (!parsed.type) {
      console.warn('[Queue] Message missing required type field');
      return;
    }
    
    if (parsed.type === 'image-prediction') {
      if (imagePredictionQueue.length >= 100) {
        console.warn('[ImageQueue] Queue full, dropping oldest message');
        imagePredictionQueue.shift();
      }
      
      imagePredictionQueue.push(message);
      
      if (!isImagePredictionProcessing) {
        try {
          processImagePredictionQueue();
        } catch (err) {
          console.error('[ImageQueue] Failed to start processor:', err);
          isImagePredictionProcessing = false; 
        }
      }
    } else {
  if (frontendUIClients.size === 0) {
    handleBackendMessage(message).catch(console.error);
    return;
  }

  if (messageQueue.length >= MESSAGE_QUEUE_SIZE) {
    console.warn('[Queue] Regular queue over 1000 – flushing all but latest snapshot');
    messageQueue.length = 0;              
  }
  messageQueue.push(message);
  if (!isProcessingQueue) processMessageQueue();
    }
  } catch (err) {
    console.error('[Queue] Invalid JSON message:', err.message);
  }
}

function processImagePredictionQueue() {
  if (isImagePredictionProcessing || imagePredictionQueue.length === 0) return;
  
  isImagePredictionProcessing = true;
  console.log(`[ImageQueue] Starting processor with ${imagePredictionQueue.length} messages`);
  
  // Track activity to detect stuck processors
  let lastActivityTimestamp = Date.now();
  let messageProcessedCount = 0;
  
  const interval = setInterval(async () => {
    // Processing progress monitor
    const now = Date.now();
    const timeSinceLastActivity = now - lastActivityTimestamp;
    
    // If no activity for 5 minutes, reset the processor
    if (timeSinceLastActivity > 300000) { // 5 minutes
      console.error(`[ImageQueue] Processor appears stuck - no activity for ${timeSinceLastActivity}ms. Resetting.`);
      clearInterval(interval);
      isImagePredictionProcessing = false;
      // Restart the processor
      setTimeout(() => processImagePredictionQueue(), 1000);
      return;
    }
    
    // Log queue status when there are items
    if (imagePredictionQueue.length > 0) {
      console.log(`[ImageQueue] Items remaining: ${imagePredictionQueue.length}`);
    }
    
    // Stop on shutdown
    if (isShuttingDown) {
      clearInterval(interval);
      isImagePredictionProcessing = false;
      console.log('[ImageQueue] Queue processor stopped - shutdown requested');
      return;
    }

    // If queue is empty, continue running but don't process anything
    if (imagePredictionQueue.length === 0) {
      return;
    }

    const message = imagePredictionQueue.shift();
    const retryCount = getRetryCount(message);
    
    try {
      const startTime = Date.now();
      await handleBackendMessage(message);
      broadcastToFrontendUIClients(message);
      
      // Update activity tracking
      lastActivityTimestamp = Date.now();
      messageProcessedCount++;
      
      // Optional: log processing time if it's unusually long
      const processingTime = lastActivityTimestamp - startTime;
      if (processingTime > 5000) {
        console.warn(`[ImageQueue] Message took ${processingTime}ms to process`);
      }
      
    } catch (error) {
      console.error(`[ImageQueue] Error processing message:`, error);
      
      // Return to queue with retry tracking if below max retries
      if (retryCount < MAX_RETRIES && imagePredictionQueue.length < 50) {
        const markedMessage = markRetry(message);
        console.warn(`[ImageQueue] Re-queueing failed message (retry ${retryCount + 1}/${MAX_RETRIES})`);
        imagePredictionQueue.unshift(markedMessage);
      } else {
        console.warn('[ImageQueue] Dropping failed message - max retries or queue full');
      }
      
      // Still update activity timestamp even on error
      lastActivityTimestamp = Date.now();
    }
  }, 600);
  
  // Additional safeguard: periodically check processor health
  const healthCheckInterval = setInterval(() => {
    // If we're shutting down, stop health checks
    if (isShuttingDown) {
      clearInterval(healthCheckInterval);
      return;
    }
    
    // If we've somehow lost our processor flag but interval is still running
    if (!isImagePredictionProcessing) {
      console.warn('[ImageQueue] Health check detected orphaned interval. Cleaning up.');
      clearInterval(interval);
      clearInterval(healthCheckInterval);
      return;
    }
    
    // Log processing stats occasionally
    console.log(`[ImageQueue] Health check: ${messageProcessedCount} messages processed, last activity ${Date.now() - lastActivityTimestamp}ms ago`);
  }, 60000); // Check every minute
}

async function processMessageQueue() {
  if (isProcessingQueue || messageQueue.length === 0) return;
  isProcessingQueue = true;
  const startTime = Date.now();
  while (messageQueue.length > 0) {
    if (Date.now() - startTime > 30_000) {
      console.warn('[Queue] Draining took >30 s; wiping remainder and requesting snapshot');
      messageQueue.length = 0;
      requestFullState();   
      break;
    }
    const message = messageQueue.shift();
    try {
      await handleBackendMessage(message);
      broadcastToFrontendUIClients(message);
    } catch (error) {
      console.error('[Queue] Error processing message:', error);
      if (messageQueue.length < MESSAGE_QUEUE_SIZE) {
        messageQueue.unshift(message);
      }
    }
  }
  isProcessingQueue = false;
  if (messageQueue.length) processMessageQueue();
}

async function connectToBackend() {
  console.log('Connecting to backend:', BACKEND_WS_URL);
  console.log('Using protocol:', 'frontend-protocol');
  if (backendWs) {
    backendWs.removeAllListeners();
    backendWs.terminate();
    backendWs = null;
  }
  try {
    backendWs = new WebSocket(BACKEND_WS_URL, 'frontend-protocol');
    backendWs.on('open', () => {
      isBackendConnected = true;
      reconnectAttempt = 0;
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
      requestFullState();
    });
    backendWs.on('message', (message) => {
      try {
        queueBackendMessage(message);
      } catch (error) {
        console.error('Error handling backend message:', error);
      }
    });
    backendWs.on('close', (code, reason) => {
      console.warn(`Backend WebSocket closed. Code: ${code}, Reason: ${reason}`);
      isBackendConnected = false;
      backendWs = null;
      if (!isShuttingDown) {
        scheduleReconnect();
      }
    });
    backendWs.on('error', (error) => {
      console.warn('[WebSocket] Backend connection error:', error.message);
      if (backendWs) {
        backendWs.terminate();
        backendWs = null;
      }
    });
  } catch (error) {
    console.error('Error establishing WebSocket connection:', error);
    if (!isShuttingDown) {
      scheduleReconnect();
    }
  }
}

function setupConnectionMonitor() {
  setInterval(() => {
    if (!isBackendConnected || !backendWs || backendWs.readyState !== WebSocket.OPEN) {
      console.warn('[Monitor] Backend connection appears down; attempting reconnect...');
      if (backendWs) {
        backendWs.terminate();
        backendWs = null;
      }
      scheduleReconnect();
    }
  }, 60000);
}

function scheduleReconnect() {
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (reconnectAttempt >= MAX_RECONNECT_ATTEMPTS) {
    console.error('Max reconnection attempts reached. Will retry again in 5 minutes.');
    reconnectTimer = setTimeout(() => {
      reconnectAttempt = 0;
      connectToBackend();
    }, 5 * 60 * 1000); 
    return;
  }
  
  const jitter = Math.floor(Math.random() * 500);
  const delay = Math.min(
    INITIAL_RECONNECT_DELAY * Math.pow(2, reconnectAttempt) + jitter,
    MAX_RECONNECT_DELAY
  );
  console.log(`Scheduling reconnect attempt ${reconnectAttempt + 1}/${MAX_RECONNECT_ATTEMPTS} in ${delay}ms`);
  reconnectTimer = setTimeout(() => {
    reconnectAttempt++;
    connectToBackend();
  }, delay);
}

function requestFullState() {
  if (backendWs && backendWs.readyState === WebSocket.OPEN) {
    const msg = JSON.stringify({ type: 'request-full-state' });
    backendWs.send(msg, (err) => {
      if (err) console.error('Error requesting full-state:', err.message);
    });
  }
}

async function handleBackendMessage(message) {
  try {
    const data = JSON.parse(message);

    switch (data.type) {
      case 'full-state':
        currentTokens = data.tokens || [];
        currentCounters = data.counters || { catCount: 0, dogCount: 0, otherCount: 0 };
        currentTrendingWords = data.trendingWords || currentTrendingWords;
        processingToken = data.processingToken || processingToken;
        if (data.sentimentHistory) {
          currentSentiment.oneHour = data.sentimentHistory.oneHour;
          currentSentiment.fourHours = data.sentimentHistory.fourHours;
          currentSentiment.twelveHours = data.sentimentHistory.twelveHours;
          currentSentiment.twentyFourHour = data.sentimentHistory.twentyFourHour;
          currentSentiment.lifetimeAvg = data.sentimentHistory.lifetimeAvg;
        }
        break;
      case 'counters-update':
        currentCounters = {
          catCount: data.catCount,
          dogCount: data.dogCount,
          otherCount: data.otherCount
        };
        break;
      case 'trending-words-update':
        if (Array.isArray(data.words)) {
          scheduleTTS(data.words);             
          currentTrendingWords = data.words;
        }
        break;
      case 'sentiment-history':
		currentSentiment.oneHour = data.oneHour;
		currentSentiment.fourHours = data.fourHours;
		currentSentiment.twelveHours = data.twelveHours;
		currentSentiment.twentyFourHour = data.twentyFourHour;
		currentSentiment.lifetimeAvg = data.lifetimeAvg;
		break;
      case 'token-list-update':
        currentTokens = data.tokens || [];
        break;
      case 'cat-dog-images-update':
        console.log('Received cat/dog arrays from backend:', data);
        currentCatImages = data.catImages;
        currentDogImages = data.dogImages;
        break;
      case 'image-prediction':
        processingToken = {
          ...processingToken,
          tokenAddress: data.tokenAddress || 'N/A',
          imageUrl: data.imageUrl,
          classification: data.classification,
          confidence: (data.confidence * 100).toFixed(2) + '%',
          tokenTicker: data.tokenTicker || 'N/A'
        };
        break;
      case 'vader-sentiment':
        if (data.compound !== undefined) {
          console.log('VADER sentiment received:', data.compound);
        }
        if (data.analyzedText) {
          addRollingText(data.analyzedText);
        }
        break;
      default:
        console.warn('Unknown message type from backend:', data.type);
        break;
    }
  } catch (err) {
    console.warn('Error parsing backend message:', err.message);
  }
}

function setupQueueMonitoring() {
  setInterval(() => {
    // Only log when queue sizes are notable
    if (imagePredictionQueue.length > 10) {
      console.log(`[Monitor] Image prediction queue size: ${imagePredictionQueue.length}`);
    }
    if (messageQueue.length > 50) {
      console.log(`[Monitor] General message queue size: ${messageQueue.length}`);
    }
  }, 10000); // Check every 10 seconds
}

function gracefulShutdownFrontend(signal) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  
  console.log(`Received ${signal}. Initiating graceful shutdown...`);
  console.log(`Queue states - Image: ${imagePredictionQueue.length}, Regular: ${messageQueue.length}`);
  
  // Allow some time for queues to flush if not empty
  const shutdownDelay = (imagePredictionQueue.length > 0 || messageQueue.length > 0) ? 5000 : 1000;
  
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  
  if (frontendWebSocketServer) {
    console.log('Closing frontend WebSocket server...');
    frontendWebSocketServer.close(() => {
      console.log('Frontend WebSocket server closed.');
    });
  }
  
  if (backendWs) {
    backendWs.removeAllListeners();
    backendWs.terminate();
    backendWs = null;
  }
  
  console.log(`Allowing ${shutdownDelay}ms for cleanup before exit...`);
  setTimeout(() => {
    console.log('Forcing exit now.');
    process.exit(1);
  }, shutdownDelay);
}

function setupHeartbeat() {
  let missedPongs = 0;
  setInterval(() => {
    if (backendWs && backendWs.readyState === WebSocket.OPEN) {
      try {
        backendWs.ping();
        const pongTimeout = setTimeout(() => {
          missedPongs++;
          console.warn(`[Heartbeat] Missed pong (count: ${missedPongs}), terminating connection`);
          backendWs.terminate();
        }, 10000);
        backendWs.once('pong', () => {
          missedPongs = 0;
          clearTimeout(pongTimeout);
        });
      } catch (error) {
        console.warn('[Heartbeat] Error sending ping:', error.message);
        backendWs.terminate();
      }
    }
  }, 30000);
}

function setupFrontendSignalListeners() {
  const signals = ['SIGINT', 'SIGTERM'];
  signals.forEach(signal => {
    process.on(signal, () => gracefulShutdownFrontend(signal));
  });
  process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    gracefulShutdownFrontend('uncaughtException');
  });
  process.on('unhandledRejection', (reason) => {
    console.error('Unhandled Rejection:', reason);
    gracefulShutdownFrontend('unhandledRejection');
  });
}

// Periodic pruning of stale clientStateRequests entries
function pruneClientStateRequests() {
  const now = Date.now();
  let deleted = 0;
  for (const [ip, times] of clientStateRequests) {
    const recent = times.filter(t => now - t < CLIENT_STATE_WINDOW_MS);
    if (recent.length) {
      // Keep only recent timestamps
      clientStateRequests.set(ip, recent);
    } else {
      clientStateRequests.delete(ip);
      deleted++;
    }
  }
  if (deleted > 0) {
    console.log(`[RateLimit] Pruned ${deleted} stale clientStateRequests entr${deleted === 1 ? 'y' : 'ies'}.`);
  }
}

function main() {
  console.log('Starting frontend server...');
  try {
    startFrontendWebSocketServer();
    
    // Add startup delay before connecting to backend
    console.log('Waiting 5 seconds before connecting to backend...');
    setTimeout(() => {
      connectToBackend();
    }, 5000);
    
    setupFrontendSignalListeners();
    setupHeartbeat();
    setupConnectionMonitor();
    
    // No immediate analytics runs or intervals
	// Start periodic pruning of rate-limit state
    setInterval(pruneClientStateRequests, CLIENT_STATE_PRUNE_EVERY_MS);
    
    app.listen(PORT, () => {
      console.log(`Express server listening on port ${PORT}`);
    });
    
    // Start the analytics scheduler after a delay
    setTimeout(() => {
      scheduleNextAnalyticsJob();
    }, 30 * 1000);
  } catch (error) {
    console.error('Fatal error starting application:', error);
    process.exit(1);
  }
}
main();
