#!/usr/bin/env python
import sys
import os
import logging
import argparse
import json
import subprocess
import re
from tempfile import NamedTemporaryFile
import shutil

# Ensure audio directory exists before logging setup
audio_dir = "/var/www/frontend/public/audio"
os.makedirs(audio_dir, exist_ok=True)

log_file = os.path.join(audio_dir, 'tts_debug.log')
log_handler = logging.FileHandler(log_file, delay=True)
log_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logger = logging.getLogger('tts_script')
logger.setLevel(logging.DEBUG)
logger.addHandler(log_handler)

# Pre-flight dependency check
required_bins = ['espeak', 'mbrola', 'sox']
enable_mbrola = True
for cmd in required_bins:
    if shutil.which(cmd) is None:
        logger.warning(f"'{cmd}' not found—disabling MBROLA pipeline.")
        enable_mbrola = False


def sanitize_phonemes(pho_path):
    """
    Enhanced phoneme sanitization for MBROLA to handle challenging words
    """
    try:
        with open(pho_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Original sanitization
        sanitized = re.sub(r'([A-Z])~', r"\1", content)
        
        # Advanced sanitization for better handling of complex words
        # 1. Normalize pause durations between problematic phonemes
        sanitized = re.sub(r'([ptkbdgfvszʃʒhmnŋlrwj])\1+', r"\1\1", sanitized, flags=re.IGNORECASE)
        
        # 2. Add minimum durations to phonemes to prevent ultra-short sounds
        sanitized = re.sub(r'(\s[0-9]+\s+)([0-9]{1,2})(\s)', r'\1100\3', sanitized)
        
        # 3. Add breathing pauses around potentially problematic sequences
        consonant_clusters = r'([ptkbdgfvszʃʒ][ptkbdgfvszʃʒ][ptkbdgfvszʃʒ]+)'
        sanitized = re.sub(consonant_clusters, r'_ 50 10 \1', sanitized, flags=re.IGNORECASE)
        
        with open(pho_path, 'w', encoding='utf-8') as f:
            f.write(sanitized)
        
        logger.debug("Enhanced phoneme sanitization applied to handle complex words")
    except Exception as e:
        logger.warning(f"Failed to sanitize phonemes: {e}")


def debug_phoneme_file(pho_path):
    """Log phoneme file content for debugging"""
    try:
        with open(pho_path, 'r', encoding='utf-8') as f:
            content = f.read()
        logger.debug(f"Phoneme file contents:\n{content[:500]}..." if len(content) > 500 else content)
    except Exception as e:
        logger.warning(f"Failed to read phoneme file for debugging: {e}")


def generate_with_espeak_mbrola(text, output_file):
    """
    Use eSpeak + MBROLA for high-quality TTS
    """
    temp_pho_path = None
    raw_out = '/tmp/tts_output.raw'

    try:
        # Create temporary phoneme file
        with NamedTemporaryFile(suffix='.pho', delete=False) as tmp:
            temp_pho_path = tmp.name

        # eSpeak -> phoneme file
        espeak_cmd = [
            'espeak', '-v', 'mb-us2', '-s', '130', '-p', '40', 
            '-a', '150', '-k', '3', '-g', '4', '-q', '--pho', text
        ]
        with open(temp_pho_path, 'w', encoding='utf-8') as f:
            subprocess.run(espeak_cmd, stdout=f, stderr=subprocess.PIPE, check=True, timeout=30)

        # Log raw phonemes for debugging
        debug_phoneme_file(temp_pho_path)
        
        # Apply enhanced sanitization
        sanitize_phonemes(temp_pho_path)
        
        # Log sanitized phonemes
        logger.debug("Post-sanitization phoneme file:")
        debug_phoneme_file(temp_pho_path)

        # MBROLA -> raw
        mbrola_cmd = ['mbrola', '/usr/share/mbrola/us2/us2', temp_pho_path, raw_out]
        subprocess.run(mbrola_cmd, stderr=subprocess.PIPE, check=True, timeout=30)

        # SoX -> WAV
        sox_cmd = ['sox', '-r', '16000', '-e', 'signed', '-b', '16', '-c', '1', raw_out, output_file]
        subprocess.run(sox_cmd, stderr=subprocess.PIPE, check=True, timeout=30)

        # Cleanup
        for path in (temp_pho_path, raw_out):
            try: os.unlink(path)
            except: pass

        logger.debug(f"Successfully generated WAV with MBROLA: {output_file}")
        return True

    except subprocess.TimeoutExpired as e:
        logger.error(f"Timeout during MBROLA pipeline: {e}")
    except FileNotFoundError as e:
        logger.error(f"Required binary not found during MBROLA pipeline: {e}")
    except subprocess.CalledProcessError as e:
        logger.error(f"MBROLA subprocess error: {e}")
    except Exception as e:
        logger.exception(f"Unexpected MBROLA failure: {e}")
    finally:
        # Ensure cleanup on any failure
        for path in (temp_pho_path, raw_out if 'raw_out' in locals() else None):
            if path and os.path.exists(path):
                try: os.unlink(path)
                except: pass

    return False


def generate_with_espeak_direct(text, output_file):
    """
    Direct espeak fallback when MBROLA fails
    """
    try:
        # Use espeak directly to generate audio without MBROLA
        espeak_cmd = [
            'espeak', '-v', 'en-us', '-s', '130', '-p', '50', 
            '-a', '150', '-w', output_file, text
        ]
        subprocess.run(espeak_cmd, stderr=subprocess.PIPE, check=True, timeout=30)
        logger.debug(f"Successfully generated WAV with direct espeak: {output_file}")
        return True
    except Exception as e:
        logger.error(f"Direct espeak fallback failed: {e}")
        return False


def format_text_with_pauses(words):
    """Format text with commas as pauses"""
    if len(words) == 1:
        return words[0]
    return "Trending: " + ", ".join(words)


def main():
    parser = argparse.ArgumentParser(description='Generate TTS and save WAV.')
    parser.add_argument('--file', help='Path to JSON file with array of words.')
    parser.add_argument('--debug', action='store_true', help='Enable extra debug output.')
    parser.add_argument('text', nargs='?', help='Optional inline text.')
    parser.add_argument('remaining', nargs='*', help='Extra text segments.')
    args = parser.parse_args()

    if args.debug:
        # Enable console logging for debugging
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
        logger.addHandler(console_handler)
        logger.debug("Debug mode enabled")

    # Load words
    if args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                words = json.load(f)
            if not isinstance(words, list):
                raise ValueError("JSON must be a list of strings.")
            logger.debug(f"Loaded {len(words)} words from {args.file}")
        except Exception as e:
            logger.error(f"Failed to load JSON file '{args.file}': {e}")
            print(f"Error loading file '{args.file}': {e}")
            sys.exit(1)
    elif args.text:
        full = ' '.join([args.text] + args.remaining).strip()
        words = full.split()
        logger.debug(f"Using {len(words)} words from command line arguments")
    else:
        logger.error("No input provided.")
        print("Error: No input provided.")
        sys.exit(1)

    if not words:
        logger.error("Word list empty after parsing.")
        print("Error: No words to speak.")
        sys.exit(1)

    text_to_speak = format_text_with_pauses(words)
    logger.debug(f"Final text to speak: {text_to_speak}")

    output_wav = os.path.join(audio_dir, "trending-words-latest.wav")

    # Try all available TTS paths in sequence
    
    # 1. MBROLA pipeline with enhanced phoneme processing
    if enable_mbrola and generate_with_espeak_mbrola(text_to_speak, output_wav):
        print(f"Generated: {output_wav} via MBROLA")
        sys.exit(0)

    # 2. Direct espeak fallback
    logger.debug("MBROLA pipeline failed—trying direct espeak fallback.")
    if generate_with_espeak_direct(text_to_speak, output_wav):
        print(f"Generated: {output_wav} via direct espeak")
        sys.exit(0)

    # 3. pyttsx3 fallback
    logger.debug("Direct espeak fallback failed—falling back to pyttsx3.")
    try:
        import pyttsx3
        engine = pyttsx3.init()
        engine.setProperty('rate', 130)
        engine.setProperty('volume', 1.0)

        # Choose female voice if possible
        for v in engine.getProperty('voices'):
            vid = v.id.lower()
            if any(tag in vid for tag in ['female', '+f', 'woman']):
                engine.setProperty('voice', v.id)
                logger.debug(f"Using voice: {v.id}")
                break

        ssml_text = text_to_speak.replace(', ', ' <break time="500ms"/> ')
        engine.save_to_file(ssml_text, output_wav)
        engine.runAndWait()

        if os.path.exists(output_wav):
            logger.debug("WAV created successfully with pyttsx3.")
            print(f"Generated: {output_wav} via pyttsx3")
            sys.exit(0)
        else:
            raise RuntimeError("pyttsx3 did not create output file.")

    except Exception as e:
        logger.exception(f"Fallback TTS failure: {e}")
        print(f"Error generating speech: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()