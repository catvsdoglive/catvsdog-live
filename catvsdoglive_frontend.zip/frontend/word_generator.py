#!/usr/bin/env python
import os
import sys
import io
import json
import random
import re
import sqlite3
import fcntl
import time
from collections import Counter
from dotenv import load_dotenv

load_dotenv()

# Database configuration: use TEXTS_DB_PATH from environment or default
DB_PATH = os.environ.get("TEXTS_DB_PATH", "/var/www/backend/database/texts.db")

# Add lock file to prevent concurrent execution with word_counter.py
LOCK_FILE = "/tmp/texts_db_analytics.lock"

def acquire_analytics_lock():
    """Try to acquire the analytics lock file"""
    try:
        # Create or open the lock file
        lock_fd = open(LOCK_FILE, "w+")
        try:
            # Try non-blocking exclusive lock
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return lock_fd  # Return file descriptor if lock acquired
        except IOError:
            # Another process holds the lock
            lock_fd.close()
            return None
    except Exception as e:
        print(f"Error acquiring lock: {e}", file=sys.stderr)
        return None

def release_analytics_lock(lock_fd):
    """Release the analytics lock file"""
    if lock_fd:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            lock_fd.close()
            return True
        except Exception as e:
            print(f"Error releasing lock: {e}", file=sys.stderr)
            return False
    return False

# ----------------------------------------------------------------------
# Constants (unchanged from your original code)
# ----------------------------------------------------------------------
FORBIDDEN_WORDS = {
    "de", "la", "pp", "st", "sv", "th", "el", "ppa", "ma", "eai",
    "b", "c", "d", "e", "f", "g", "h", "j", 
    "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", 
    "u", "v", "w", "y", "z", "ba",
}

SUPPRESSED_WORDS = {
    "a", "an", "the", "some", "any", "all", "every", "each", "such", "what", "whatever", "which", "whichever",
    "about", "above", "across", "after", "against", "along", "amid", "amidst", "among", 
    "amongst", "around", "as", "at", "before", "behind", "below", "beneath", "beside", 
    "besides", "between", "beyond", "by", "concerning", "despite", "down", "during", 
    "except", "for", "from", "in", "inside", "into", "like", "near", "of", "off", "on", 
    "onto", "out", "outside", "over", "past", "regarding", "round", "since", "through", 
    "throughout", "till", "to", "toward", "towards", "under", "underneath", "until", 
    "unto", "up", "upon", "with", "within", "without",
    "and", "but", "or", "nor", "so", "yet", "because", "unless", "though", "although", "even", "if", "whereas", "while",
    "i", "me", "my", "mine", "myself", "you", "your", "yours", "yourself", "yourselves", 
    "he", "him", "his", "himself", "she", "her", "hers", "herself", "it", "its", "itself", 
    "we", "us", "our", "ours", "ourselves", "they", "them", "their", "theirs", "themselves",
    "am", "are", "is", "was", "were", "be", "been", "being", "have", "has", "had", 
    "having", "do", "does", "did", "doing", "would", "should", "could", "might", 
    "must", "shall", "will", "can", "may",
    "i'm", "im", "you're", "youre", "he's", "hes", "she's", "shes", "it's", "its", "we're", 
    "were", "they're", "theyre", "i've", "ive", "you've", "youve", "we've", "weve", "they've", 
    "theyve", "i'd", "id", "you'd", "youd", "he'd", "hed", "she'd", "shed", "we'd", "wed", 
    "they'd", "theyd", "i'll", "ill", "you'll", "youll", "he'll", "hell", "she'll", "shell", 
    "we'll", "well", "they'll", "theyll", "isn't", "isnt", "aren't", "arent", "wasn't", "wasnt", 
    "weren't", "werent", "hasn't", "hasnt", "haven't", "havent", "hadn't", "hadnt", "doesn't", 
    "doesnt", "don't", "dont", "didn't", "didnt", "won't", "wont", "wouldn't", "wouldnt", 
    "shan't", "shant", "shouldn't", "shouldnt", "can't", "cant", "cannot", "couldn't", "couldnt", 
    "mustn't", "mustnt", "let's", "lets", "that's", "thats", "who's", "whos", "what's", "whats", 
    "here's", "heres", "there's", "theres", "when's", "whens", "where's", "wheres", "why's", 
    "whys", "how's", "hows",
    "etc", "via", "eg", "ie", "example", "regards", "sincerely", "dear", "hi", "hello", "hey", "thanks", "thank", "please", "www", "com", "http", "https", "subject", "re", "fw", "fwd",

    # Demonstratives & determiners
    "this", "that", "these", "those", "another", "other", "others", "both", "same",

    # Common adverbs/intensifiers  
    "just", "almost", "only", "very", "also", "really", "actually", "fully",

    # Temporal/location words
    "now", "then", "here", "there", "when", "where", "again", "still", "already", "ever", "never", "always", "often", "once", "later", "last", "next", "finally",

    # Negatives
    "no", "not", "nothing",

    # Generic verbs (all forms)
    "get", "gets", "got", "getting",
    "go", "goes", "going", "went", "gone",
    "make", "makes", "making", "made",
    "take", "takes", "taking", "took", "taken",
    "need", "needs", "needed", "needing",
    "want", "wants", "wanted", "wanting",
    "see", "sees", "seeing", "saw", "seen",
    "know", "knows", "knowing", "knew", "known",
    "become", "becomes", "becoming", "became",
    "come", "comes", "coming", "came",
    "think", "thinks", "thinking", "thought",
    "say", "says", "saying", "said",
    "use", "uses", "using", "used",
    "work", "works", "working", "worked",
    "find", "finds", "finding", "found",

    # Comparatives/superlatives
    "more", "most", "less", "least", "better", "best", "good",

    # Question words
    "how", "why", "whether",

    # Quantifiers
    "one", "two", "three", "many", "much", "few", "first", "second",

    # Generic nouns
    "way", "ways", "thing", "things", "part", "parts",

    # Indefinite pronouns
    "something", "someone", "somebody", "anyone", "anybody", "everyone", "everybody", "everything",
    
    # Could keep for some contexts
    "new", "big", "little", "old", "long", "high", "low", "great", "own", "back", "free",
    
    #dev added
    "who", 
}

FALLBACK_TICKERS = [
    "INVSTR", "DEGENED", "BNKRPT", "WENLAMBO", "999xONLY", "CRASHTK", "FOMO4EVR", "APEDGEN",
    "REKTD", "BROKR", "NEETX", "SUESEC", "MEMEGOD", "MOONRUG", "GIVEMORE", "FUNDLESS",
    "DADDYELN", "BURNIT", "SADAPE", "WTFPLS", "UNOPE", "4REAL?", "ACOINLOL", "FAKEDUMP",
    "DJNTKN", "IAINTGOT", "NGMI", "POORNOW", "SELLZERO", "CHART404", "NOLAMBO", "COPIUM",
    "BUYHI", "LOSELY", "NOCASH", "DUMPIT", "SADHODL", "NOTMOON", "WHENPOOR", "PLSHELP",
    "BROKEDAO", "NOMONEY", "REDLINE", "DIPBUY", "BAGHODL", "ZEROSUM", "PAPERX", "REKTDAO",
    "SELLNOW", "NOCOIN", "BEARISH", "LIQUIDX", "CANTMOON", "FAILDEV", "GOBRKN", "SCAM1ST",
    "ZROHOPE", "HODLSAD", "YOUBROK", "DEBTMAX", "CRYONCE", "BANKRUPT", "NOPIVOT", "SLACKER",
    "HYPEFLOP", "OVERLEVR", "DYNFUD", "APELESS", "NODINERO", "TELLMOM", "2FARFETD", "CASHLESS",
    "UNREALX", "HOPELESS", "REKTRENT", "FSOON?", "BANKRBOT", "LSRMORE", "WASHEDUP", "DEGENED2",
    "FUD4EVER", "BAGREKT", "BUBBLUP", "SURGDUMP", "CRYPNOT", "XJUSTX", "LOSTFUND", "GRIFTER",
    "IOUCASH", "FUDTKN", "REKTAPE", "JOBPLZ", "PINKSLIP", "NKDMARKT", "ILOSER", "SLEPTON",
    "DEPRESSD", "BUYTHEDIP", "RADREKT", "WAILOUT", "NOUTILITY", "FUDSTORM", "NOPLZNO", "FUDRIVER",
    "NOBULLS", "SECRETLYREKT", "CREDITGONE", "ROUGHBUY", "NEVERTOP", "PANICNOW", "MORDEBT", "BURNTOKEN",
    "CRASHEDU", "MISSMOON", "URREKT", "N00BCOIN", "PAYLATER", "SADLIFE", "MEHKITTY", "GHOST3AM",
    "TAXEMPT", "PUMPAGE?", "TRAPRUG", "BAGDRAG", "STOLENOP", "DOWNBID", "FAKEGGED", "BLUFBULL",
    "WATDO?", "PEPEPSY", "2HARDRUG",
]

# ----------------------------------------------------------------------
# Database Reading Functions - Updated for better concurrency
# ----------------------------------------------------------------------
def get_all_texts_from_db(limit=10000):
    """
    Connects to the SQLite database and retrieves texts in smaller batches
    to reduce contention, with WAL mode enforced.
    """
    try:
        # Connect with enhanced settings
        conn = sqlite3.connect(DB_PATH, timeout=30.0)
        conn.row_factory = sqlite3.Row
        
        # Configure connection for optimal performance
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        conn.execute("PRAGMA busy_timeout = 10000")
        conn.execute("PRAGMA read_uncommitted = 1")  # Allow dirty reads
        conn.execute("PRAGMA cache_size = -8000")
        
        # Process in smaller batches to reduce contention
        all_texts = []
        batch_size = 1000  # Smaller batch size
        
        for offset in range(0, limit, batch_size):
            # Start read transaction
            conn.execute("BEGIN")
            
            # Get current batch
            current_limit = min(batch_size, limit - offset)
            rows = conn.execute(
                "SELECT text FROM analyzed_texts ORDER BY timestamp DESC LIMIT ? OFFSET ?",
                (current_limit, offset)
            ).fetchall()
            
            # End transaction to release locks
            conn.execute("END")
            
            if not rows:
                break
                
            all_texts.extend([row["text"] for row in rows])
            
            # Small delay between batches
            time.sleep(0.05)
        
        conn.close()
        return all_texts
    except Exception as e:
        print("Error reading from database:", e, file=sys.stderr)
        return []

def get_top_1000_words():
    """
    Reads texts from the database, splits them into tokens and counts them AS IS,
    returning up to the 1000 most common words.
    """
    word_counter = Counter()
    texts = get_all_texts_from_db(10000)
    for text in texts:
        tokens = text.split()
        word_counter.update(tokens)
    return word_counter.most_common(1000)

# ----------------------------------------------------------------------
# Token and Name Generation Functions (unchanged)
# ----------------------------------------------------------------------
def clean_word(word):
    # Normalize curly quotes -> straight quote
    word = word.replace('\u2018', "'").replace('\u2019', "'")
    # Keep only allowed characters
    return re.sub(r'[^a-zA-Z0-9\(\)\[\]\'\"\!\?]+', '', word)

def create_ticker(words_in_phrase):
    num_words = len(words_in_phrase)
    if num_words == 1:
        if random.random() < 0.5:
            ticker_candidate = random.choice(FALLBACK_TICKERS)
        else:
            ticker_candidate = words_in_phrase[0]
    elif num_words == 2:
        ticker_candidate = words_in_phrase[0] if random.random() < 0.5 else words_in_phrase[-1]
    else:
        choice = random.choice([1, 2, 3])
        if choice == 1:
            ticker_candidate = "".join(w[0] for w in words_in_phrase if w)
        elif choice == 2:
            ticker_candidate = words_in_phrase[0]
        else:
            ticker_candidate = words_in_phrase[-1]
    if not ticker_candidate.isalpha():
        return random.choice(FALLBACK_TICKERS)
    return ticker_candidate.upper()

def reorder_words(words):
    place_begin = {
        "i", "im", "i'm", "me", "my", "mine", "myself", "we", "us", "our", "ours", "ourselves",
        "you", "your", "yours", "yourself", "yourselves",
        "he", "she", "they", "him", "his", "himself", "hers", "herself",
        "it", "itself", "them", "their", "theirs", "themselves",
        "this", "that", "these", "those", "here",
        "who", "whom", "whose", "when", "why", "how", "whether",
        "wherein", "whereby", "herein", "thereof", "therein", "wherever", "whenever"
    }
    place_begin_if_len = {
        "youre", "you're", "its", "it's", "were", "we're", "theyre", "they're",
        "lets", "let's", "thats", "that's", "whos", "who's", "whats", "what's",
        "heres", "here's", "theres", "there's", "whens", "when's", "wheres", "where's",
        "whys", "why's", "hows", "how's",
        "what", "which", "while", "where"
    }
    not_allowed_last = {
        "dont", "don't", "isnt", "isn't", "arent", "aren't", "wasnt", "wasn't", "werent", "weren't",
        "hasnt", "hasn't", "havent", "haven't", "hadnt", "hadn't", "doesnt", "doesn't", "didnt", "didn't",
        "wont", "won't", "wouldnt", "wouldn't", "shant", "shan't", "shouldnt", "shouldn't",
        "cant", "can't", "cannot", "couldnt", "couldn't", "mustnt", "mustn't",
        "a", "an", "the", "all", "any", "anyone", "some", "every", "each", "such", "what", "whatever", "which", "whichever",
        "about", "above", "across", "after", "against", "along", "amid", "amidst", "among",
        "amongst", "around", "as", "at", "before", "behind", "below", "beneath", "beside",
        "besides", "between", "beyond", "by", "concerning", "despite", "down", "during",
        "except", "for", "from", "in", "inside", "into", "like", "near", "of", "off", "on",
        "onto", "out", "outside", "over", "past", "regarding", "round", "since", "through",
        "throughout", "till", "to", "toward", "towards", "under", "underneath", "until",
        "unto", "up", "upon", "with", "within", "without",
        "and", "but", "or", "nor", "so", "yet", "because", "unless", "though", "although", "even", "if", "than", "whereas", "while",
        "am", "are", "is", "was", "were", "be", "been", "being", "have", "has", "had",
        "having", "do", "does", "did", "doing", "would", "should", "could", "might",
        "must", "shall", "will", "can", "may", "get", "let", "make", "just",
        "both", "down", "each", "even", "ever", "more", "most",
        "never", "no", "not", "now", "often", "once",
        "one", "only", "other", "so", "some", "such", "then",
        "too", "very", "well",
        "hi", "example", "regards", "sincerely", "dear", "hello", "hey", "thanks", "thank", "please",
        "www", "com", "http", "https", "subject", "re", "fw", "fwd",
        "etc", "via", "eg", "ie"
    }
    def eq_any(word, variants):
        return word.lower() in variants

    for i, w in enumerate(words):
        if eq_any(w, place_begin):
            words.insert(0, words.pop(i))
            break

    if len(words) > 1:
        for i, w in enumerate(words):
            if eq_any(w, place_begin_if_len) and i != 0:
                words.insert(0, words.pop(i))
                break

    if len(words) > 1:
        last_idx = len(words) - 1
        if eq_any(words[last_idx], not_allowed_last):
            to_move = words.pop(last_idx)
            words.insert(max(0, last_idx - 1), to_move)

    return words

def apply_naming_transform(chosen_words):
    if not chosen_words:
        return ""
    transform_choices = [1, 2, 3]
    transform_weights = [0.2, 0.2, 0.6]
    transform = random.choices(transform_choices, weights=transform_weights, k=1)[0]
    result_words = chosen_words[:]
    if transform == 1:
        result_words = [w.lower() for w in result_words]
        if random.random() < 0.05:
            result_words.append("ai")
        return " ".join(result_words)
    elif transform == 2:
        result_words = [w.upper() for w in result_words]
        if random.random() < 0.05:
            result_words.append("AI")
        return " ".join(result_words)
    else:
        result_words = [w.capitalize() for w in result_words]
        do_combine = (random.random() < 0.20)
        do_append_ai = (random.random() < 0.05)
        if do_combine:
            combined = "".join(result_words)
            if do_append_ai:
                combined += "AI"
            return combined
        else:
            if do_append_ai:
                result_words.append("AI")
            return " ".join(result_words)

def weighted_sample(words, suppressed_words, num_samples):
    word_weights = [
        1 if word in suppressed_words else 4
        for word in words
    ]
    return random.choices(words, weights=word_weights, k=num_samples)

# ----------------------------------------------------------------------
# Main routine: generate 1000 names using token frequencies from the DB
# ----------------------------------------------------------------------
def main():
    texts = get_all_texts_from_db(10000)
    if not texts:
        print("No texts found in the database.", file=sys.stderr)
        sys.exit(1)
    
    # 1. Get top 1000 tokens (as they appear, without cleaning)
    top_1000_raw = get_top_1000_words()
    
    # 2. Filter out forbidden words
    filtered_tokens = [
        (tok, freq)
        for (tok, freq) in top_1000_raw
        if tok.lower() not in FORBIDDEN_WORDS
    ]
    if not filtered_tokens:
        print("No valid words found after filtering.", file=sys.stderr)
        sys.exit(1)
    
    # 3. Expand each token (cleaned) by its frequency
    cleaned_list = []
    for (raw_token, freq) in filtered_tokens:
        cleaned = clean_word(raw_token)
        if cleaned:
            cleaned_list.extend([cleaned] * freq)
    
    if not cleaned_list:
        print("All tokens became empty after cleaning.", file=sys.stderr)
        sys.exit(1)
    
    unique_cleaned = list(set(cleaned_list))
    suppressed_words = set(SUPPRESSED_WORDS)
    
    size_choices = [1, 2, 3, 4, 5]
    size_weights = [0.10, 0.20, 0.30, 0.20, 0.20]
    
    names_to_generate = 1000
    print("Generated names:")
    for _ in range(names_to_generate):
        num_words = random.choices(size_choices, weights=size_weights, k=1)[0]
        if num_words > len(unique_cleaned):
            num_words = len(unique_cleaned)
            if num_words == 0:
                break
        chosen_words = weighted_sample(unique_cleaned, suppressed_words, num_words)
        reorder_words(chosen_words)
        final_phrase = apply_naming_transform(chosen_words)
        ticker = create_ticker(chosen_words)
        if num_words > 1 and random.random() < 0.25:
            ticker = random.choice(FALLBACK_TICKERS)
        print(f"{final_phrase} [{ticker}]")

if __name__ == "__main__":
    # Try to acquire lock first
    lock_fd = acquire_analytics_lock()
    if not lock_fd:
        print("Another analytics job is running, exiting.", file=sys.stderr)
        sys.exit(0)
    
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding="utf-8", errors="replace")
        main()
    finally:
        # Always release the lock when done
        release_analytics_lock(lock_fd)