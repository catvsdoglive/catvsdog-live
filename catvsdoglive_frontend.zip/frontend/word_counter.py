#!/usr/bin/env python
import os
import sys
import io
import json
import sqlite3
import fcntl
import time
from collections import Counter
from dotenv import load_dotenv
import re

load_dotenv()

# Get the database path from environment or use default
TEXTS_DB_PATH = os.environ.get('TEXTS_DB_PATH', '/var/www/backend/database/texts.db')

# Add lock file to prevent concurrent execution with word_generator.py
LOCK_FILE = "/tmp/texts_db_analytics.lock"

def acquire_analytics_lock():
    """Try to acquire the analytics lock file"""
    try:
        # Create or open the lock file
        lock_fd = open(LOCK_FILE, "w+")
        try:
            # Try non-blocking exclusive lock
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return lock_fd  # Return file descriptor if lock acquired
        except IOError:
            # Another process holds the lock
            lock_fd.close()
            return None
    except Exception as e:
        print(f"Error acquiring lock: {e}", file=sys.stderr)
        return None

def release_analytics_lock(lock_fd):
    """Release the analytics lock file"""
    if lock_fd:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
            lock_fd.close()
            return True
        except Exception as e:
            print(f"Error releasing lock: {e}", file=sys.stderr)
            return False
    return False

def get_db_connection():
    """
    Create a connection to the texts database with WAL mode enforced.
    Returns a sqlite3 connection object.
    """
    # Ensure the database directory exists
    os.makedirs(os.path.dirname(TEXTS_DB_PATH), exist_ok=True)
    
    # Create a connection with row factory
    conn = sqlite3.connect(TEXTS_DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    
    # Enforce WAL mode and optimize database settings
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA busy_timeout = 10000")
    conn.execute("PRAGMA read_uncommitted = 1")  # Allow dirty reads for analytics
    conn.execute("PRAGMA cache_size = -8000")
    
    # Create table if it doesn't exist (only one column for full text)
    conn.execute('''
        CREATE TABLE IF NOT EXISTS analyzed_texts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            timestamp TEXT DEFAULT (datetime('now'))
        )
    ''')
    
    conn.execute('''
        CREATE INDEX IF NOT EXISTS idx_analyzed_texts_timestamp 
        ON analyzed_texts(timestamp)
    ''')
    
    conn.commit()
    return conn

def is_emoji_code(word):
    """Check if word is an emoji/slack code format like :fire: or :police_car_light:"""
    return bool(re.match(r'^:[^:]+:$', word))

def is_punctuation_only(word):
    """Check if word contains only punctuation/special characters (no alphanumeric)"""
    # Remove all alphanumeric characters and check if anything remains
    # If the word becomes empty after removing non-alphanumeric, it was pure punctuation
    return not bool(re.search(r'[a-zA-Z0-9]', word))

def should_filter_word(word, excluded_words, clean_word_func):
    """
    Determine if a word should be filtered out.
    Returns True if the word should be excluded, False otherwise.
    """
    # Filter emoji codes like :fire: or :police_car_light:
    if is_emoji_code(word):
        return True
    
    # Filter pure punctuation like —, •, !, ?, etc.
    if is_punctuation_only(word):
        return True
    
    # Filter based on suppressed/forbidden words (case-insensitive, using cleaner)
    cleaned = clean_word_func(word).lower()
    if cleaned in excluded_words:
        return True
    
    # Additional check: if cleaning removes everything, filter it out
    if not cleaned:
        return True
    
    return False

def count_words_from_database(limit=None):
    """
    Counts word frequencies from the texts in the database.
    Uses smaller batches and read-uncommitted mode for minimal contention.
    
    Args:
        limit: Maximum number of texts to process (None = no limit)
        
    Returns:
        Counter object with words as keys and counts as values
    """
    word_counter = Counter()
    
    try:
        # Connect to the database with optimized settings
        conn = get_db_connection()
        
        # Get row count first
        row_count = conn.execute("SELECT COUNT(*) FROM analyzed_texts").fetchone()[0]
        
        # Use smaller batch size to reduce lock contention
        batch_size = 1000  # Reduced from 5000
        offset = 0
        
        while True:
            try:
                # Begin read-only transaction for each batch
                conn.execute("BEGIN")
                
                # Get a batch of texts with timeout
                if limit is not None:
                    # Apply limit if specified
                    query = """
                        SELECT text 
                        FROM analyzed_texts 
                        ORDER BY timestamp DESC
                        LIMIT ? OFFSET ?
                    """
                    rows = conn.execute(query, (min(batch_size, limit - offset), offset)).fetchall()
                else:
                    # No limit - process all texts
                    query = """
                        SELECT text 
                        FROM analyzed_texts 
                        ORDER BY timestamp DESC
                        LIMIT ? OFFSET ?
                    """
                    rows = conn.execute(query, (batch_size, offset)).fetchall()
                
                # End transaction quickly to release locks
                conn.execute("END")
                
            except (KeyboardInterrupt, SystemExit):
                # Handle interruption gracefully
                conn.close()
                return word_counter
            except Exception as e:
                # Log error but continue with what we have
                print(f"Error in batch query: {e}", file=sys.stderr)
                break
            
            # Exit loop if no more rows
            if not rows:
                break
            
            # Process each row in this batch
            for row in rows:
                text = row['text']
                # Split text into words and update counter
                words = text.split()
                word_counter.update(words)
            
            # Update offset for next batch
            offset += batch_size
            
            # Add a small delay between batches to allow writers
            time.sleep(0.05)
            
            # Exit if we've reached the limit
            if limit is not None and offset >= limit:
                break
        
        conn.close()
        return word_counter
        
    except (KeyboardInterrupt, SystemExit):
        # Return what we have so far on interruption
        return word_counter
    except Exception as e:
        print(f"Error counting words: {e}", file=sys.stderr)
        return Counter()  # Return empty counter on error

if __name__ == "__main__":
    # Try to acquire the lock first
    lock_fd = acquire_analytics_lock()
    if not lock_fd:
        print("Another analytics job is running, exiting.", file=sys.stderr)
        sys.exit(0)
    
    try:
        # Force sys.stdout to UTF-8 for Windows
        sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8', errors='replace')
        
        # By default, process ALL texts (no limit)
        # You can add a command line arg to set a limit if needed
        limit = None
        if len(sys.argv) > 1 and sys.argv[1].isdigit():
            limit = int(sys.argv[1])
        
        # --- Import suppression, forbidden, and cleaning from word_generator.py ---
        # Ensure local import works regardless of CWD
        CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
        if CURRENT_DIR not in sys.path:
            sys.path.insert(0, CURRENT_DIR)
        try:
            from word_generator import SUPPRESSED_WORDS, FORBIDDEN_WORDS, clean_word  # noqa: F401
        except Exception:
            # Fallback to safe defaults if import fails
            SUPPRESSED_WORDS = set()
            FORBIDDEN_WORDS = set()
            def clean_word(w: str) -> str:
                w = w.replace('\u2018', "'").replace('\u2019', "'")
                return re.sub(r"[^a-zA-Z0-9\(\)\[\]'\"!\?]+", "", w)

        counts = count_words_from_database(limit)

        total_words = sum(counts.values())
        unique_words = len(counts)

        # Combine both sets for filtering
        excluded_words = SUPPRESSED_WORDS | FORBIDDEN_WORDS

        # Filter out suppressed, forbidden, emoji codes, and punctuation
        filtered_counts = Counter({
            w: f for w, f in counts.items()
            if not should_filter_word(w, excluded_words, clean_word)
        })

        # Build top-1000 AFTER filtering
        top_1000 = [{"word": w, "freq": f} for w, f in filtered_counts.most_common(1000)]
        
        result = {
            "totalWords": total_words,
            "uniqueWords": unique_words,
            "topWords": top_1000
        }
        
        print(json.dumps(result, ensure_ascii=False))
        
    except (KeyboardInterrupt, SystemExit):
        # Handle interruption gracefully - output valid JSON
        print(json.dumps({"totalWords": 0, "uniqueWords": 0, "topWords": []}))
    except Exception as e:
        # Return empty result on error without logging the error
        print(json.dumps({"totalWords": 0, "uniqueWords": 0, "topWords": []}))
    finally:
        # Always release the lock when done
        release_analytics_lock(lock_fd)